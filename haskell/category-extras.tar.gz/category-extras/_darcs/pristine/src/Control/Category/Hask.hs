-------------------------------------------------------------------------------------------
-- |
-- Module	: Control.Category.Hask
-- Copyright 	: 2008 Edward Kmett
-- License	: BSD
--
-- Maintainer	: Edward Kmett <ekmett@gmail.com>
-- Stability	: experimental
-- Portability	: portable
--
-------------------------------------------------------------------------------------------
module Control.Category.Hask
	( Hask
	) where

type Hask = (->) 
