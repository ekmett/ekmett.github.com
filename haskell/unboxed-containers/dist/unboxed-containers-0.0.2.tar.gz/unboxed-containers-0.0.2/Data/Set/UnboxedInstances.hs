

instance US Int where
    data USet Int = IntTip | IntBin {-# UNPACK #-} !Size {-# UNPACK #-} !Int !(USet Int) !(USet Int)
    view IntTip = Tip
    view (IntBin s a l r) = Bin s (a) l r
    tip = IntTip
    bin s (a) = IntBin s a

instance US Char where
    data USet Char = CharTip | CharBin {-# UNPACK #-} !Size {-# UNPACK #-} !Char !(USet Char) !(USet Char)
    view CharTip = Tip
    view (CharBin s a l r) = Bin s (a) l r
    tip = CharTip
    bin s (a) = CharBin s a

instance US Int8 where
    data USet Int8 = Int8Tip | Int8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int8 !(USet Int8) !(USet Int8)
    view Int8Tip = Tip
    view (Int8Bin s a l r) = Bin s (a) l r
    tip = Int8Tip
    bin s (a) = Int8Bin s a

instance US Int16 where
    data USet Int16 = Int16Tip | Int16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int16 !(USet Int16) !(USet Int16)
    view Int16Tip = Tip
    view (Int16Bin s a l r) = Bin s (a) l r
    tip = Int16Tip
    bin s (a) = Int16Bin s a

instance US Int32 where
    data USet Int32 = Int32Tip | Int32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int32 !(USet Int32) !(USet Int32)
    view Int32Tip = Tip
    view (Int32Bin s a l r) = Bin s (a) l r
    tip = Int32Tip
    bin s (a) = Int32Bin s a

instance US Int64 where
    data USet Int64 = Int64Tip | Int64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int64 !(USet Int64) !(USet Int64)
    view Int64Tip = Tip
    view (Int64Bin s a l r) = Bin s (a) l r
    tip = Int64Tip
    bin s (a) = Int64Bin s a

instance US Word8 where
    data USet Word8 = Word8Tip | Word8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word8 !(USet Word8) !(USet Word8)
    view Word8Tip = Tip
    view (Word8Bin s a l r) = Bin s (a) l r
    tip = Word8Tip
    bin s (a) = Word8Bin s a

instance US Word16 where
    data USet Word16 = Word16Tip | Word16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word16 !(USet Word16) !(USet Word16)
    view Word16Tip = Tip
    view (Word16Bin s a l r) = Bin s (a) l r
    tip = Word16Tip
    bin s (a) = Word16Bin s a

instance US Word32 where
    data USet Word32 = Word32Tip | Word32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word32 !(USet Word32) !(USet Word32)
    view Word32Tip = Tip
    view (Word32Bin s a l r) = Bin s (a) l r
    tip = Word32Tip
    bin s (a) = Word32Bin s a

instance US Word64 where
    data USet Word64 = Word64Tip | Word64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word64 !(USet Word64) !(USet Word64)
    view Word64Tip = Tip
    view (Word64Bin s a l r) = Bin s (a) l r
    tip = Word64Tip
    bin s (a) = Word64Bin s a

instance US Double where
    data USet Double = DoubleTip | DoubleBin {-# UNPACK #-} !Size {-# UNPACK #-} !Double !(USet Double) !(USet Double)
    view DoubleTip = Tip
    view (DoubleBin s a l r) = Bin s (a) l r
    tip = DoubleTip
    bin s (a) = DoubleBin s a

instance US Float where
    data USet Float = FloatTip | FloatBin {-# UNPACK #-} !Size {-# UNPACK #-} !Float !(USet Float) !(USet Float)
    view FloatTip = Tip
    view (FloatBin s a l r) = Bin s (a) l r
    tip = FloatTip
    bin s (a) = FloatBin s a

instance US Integer where
    data USet Integer = IntegerTip | IntegerBin {-# UNPACK #-} !Size {-# UNPACK #-} !Integer !(USet Integer) !(USet Integer)
    view IntegerTip = Tip
    view (IntegerBin s a l r) = Bin s (a) l r
    tip = IntegerTip
    bin s (a) = IntegerBin s a

instance US (Boxed a) where
    data USet (Boxed a) = BoxedTip | BoxedBin {-# UNPACK #-} !Size (Boxed a) !(USet (Boxed a)) !(USet (Boxed a))
    view BoxedTip = Tip
    view (BoxedBin s a l r) = Bin s (a) l r
    tip = BoxedTip
    bin s (a) = BoxedBin s a

instance US (Int,Int) where
    data USet (Int,Int) = IntIntTip | IntIntBin {-# UNPACK #-} !Size {-# UNPACK #-} !Int{-# UNPACK #-} !Int !(USet (Int,Int)) !(USet (Int,Int))
    view IntIntTip = Tip
    view (IntIntBin s a b l r) = Bin s (a,b) l r
    tip = IntIntTip
    bin s (a,b) = IntIntBin s a b

instance US (Int,Int,Int) where
    data USet (Int,Int,Int) = IntIntIntTip | IntIntIntBin {-# UNPACK #-} !Size {-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int !(USet (Int,Int,Int)) !(USet (Int,Int,Int))
    view IntIntIntTip = Tip
    view (IntIntIntBin s a b c l r) = Bin s (a,b,c) l r
    tip = IntIntIntTip
    bin s (a,b,c) = IntIntIntBin s a b c

instance US (Int,Int,Int,Int) where
    data USet (Int,Int,Int,Int) = IntIntIntIntTip | IntIntIntIntBin {-# UNPACK #-} !Size {-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int !(USet (Int,Int,Int,Int)) !(USet (Int,Int,Int,Int))
    view IntIntIntIntTip = Tip
    view (IntIntIntIntBin s a b c d l r) = Bin s (a,b,c,d) l r
    tip = IntIntIntIntTip
    bin s (a,b,c,d) = IntIntIntIntBin s a b c d

instance US (Int,Int,Int,Int,Int) where
    data USet (Int,Int,Int,Int,Int) = IntIntIntIntIntTip | IntIntIntIntIntBin {-# UNPACK #-} !Size {-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int !(USet (Int,Int,Int,Int,Int)) !(USet (Int,Int,Int,Int,Int))
    view IntIntIntIntIntTip = Tip
    view (IntIntIntIntIntBin s a b c d e l r) = Bin s (a,b,c,d,e) l r
    tip = IntIntIntIntIntTip
    bin s (a,b,c,d,e) = IntIntIntIntIntBin s a b c d e

instance US (Int,Int,Int,Int,Int,Int) where
    data USet (Int,Int,Int,Int,Int,Int) = IntIntIntIntIntIntTip | IntIntIntIntIntIntBin {-# UNPACK #-} !Size {-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int !(USet (Int,Int,Int,Int,Int,Int)) !(USet (Int,Int,Int,Int,Int,Int))
    view IntIntIntIntIntIntTip = Tip
    view (IntIntIntIntIntIntBin s a b c d e f l r) = Bin s (a,b,c,d,e,f) l r
    tip = IntIntIntIntIntIntTip
    bin s (a,b,c,d,e,f) = IntIntIntIntIntIntBin s a b c d e f

instance US (Int,Int,Int,Int,Int,Int,Int) where
    data USet (Int,Int,Int,Int,Int,Int,Int) = IntIntIntIntIntIntIntTip | IntIntIntIntIntIntIntBin {-# UNPACK #-} !Size {-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int !(USet (Int,Int,Int,Int,Int,Int,Int)) !(USet (Int,Int,Int,Int,Int,Int,Int))
    view IntIntIntIntIntIntIntTip = Tip
    view (IntIntIntIntIntIntIntBin s a b c d e f g l r) = Bin s (a,b,c,d,e,f,g) l r
    tip = IntIntIntIntIntIntIntTip
    bin s (a,b,c,d,e,f,g) = IntIntIntIntIntIntIntBin s a b c d e f g

instance US (Int,Int,Int,Int,Int,Int,Int,Int) where
    data USet (Int,Int,Int,Int,Int,Int,Int,Int) = IntIntIntIntIntIntIntIntTip | IntIntIntIntIntIntIntIntBin {-# UNPACK #-} !Size {-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int !(USet (Int,Int,Int,Int,Int,Int,Int,Int)) !(USet (Int,Int,Int,Int,Int,Int,Int,Int))
    view IntIntIntIntIntIntIntIntTip = Tip
    view (IntIntIntIntIntIntIntIntBin s a b c d e f g h l r) = Bin s (a,b,c,d,e,f,g,h) l r
    tip = IntIntIntIntIntIntIntIntTip
    bin s (a,b,c,d,e,f,g,h) = IntIntIntIntIntIntIntIntBin s a b c d e f g h

instance US (Int,Int,Int,Int,Int,Int,Int,Int,Int) where
    data USet (Int,Int,Int,Int,Int,Int,Int,Int,Int) = IntIntIntIntIntIntIntIntIntTip | IntIntIntIntIntIntIntIntIntBin {-# UNPACK #-} !Size {-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int{-# UNPACK #-} !Int !(USet (Int,Int,Int,Int,Int,Int,Int,Int,Int)) !(USet (Int,Int,Int,Int,Int,Int,Int,Int,Int))
    view IntIntIntIntIntIntIntIntIntTip = Tip
    view (IntIntIntIntIntIntIntIntIntBin s a b c d e f g h i l r) = Bin s (a,b,c,d,e,f,g,h,i) l r
    tip = IntIntIntIntIntIntIntIntIntTip
    bin s (a,b,c,d,e,f,g,h,i) = IntIntIntIntIntIntIntIntIntBin s a b c d e f g h i

instance US (Char,Char) where
    data USet (Char,Char) = CharCharTip | CharCharBin {-# UNPACK #-} !Size {-# UNPACK #-} !Char{-# UNPACK #-} !Char !(USet (Char,Char)) !(USet (Char,Char))
    view CharCharTip = Tip
    view (CharCharBin s a b l r) = Bin s (a,b) l r
    tip = CharCharTip
    bin s (a,b) = CharCharBin s a b

instance US (Char,Char,Char) where
    data USet (Char,Char,Char) = CharCharCharTip | CharCharCharBin {-# UNPACK #-} !Size {-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char !(USet (Char,Char,Char)) !(USet (Char,Char,Char))
    view CharCharCharTip = Tip
    view (CharCharCharBin s a b c l r) = Bin s (a,b,c) l r
    tip = CharCharCharTip
    bin s (a,b,c) = CharCharCharBin s a b c

instance US (Char,Char,Char,Char) where
    data USet (Char,Char,Char,Char) = CharCharCharCharTip | CharCharCharCharBin {-# UNPACK #-} !Size {-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char !(USet (Char,Char,Char,Char)) !(USet (Char,Char,Char,Char))
    view CharCharCharCharTip = Tip
    view (CharCharCharCharBin s a b c d l r) = Bin s (a,b,c,d) l r
    tip = CharCharCharCharTip
    bin s (a,b,c,d) = CharCharCharCharBin s a b c d

instance US (Char,Char,Char,Char,Char) where
    data USet (Char,Char,Char,Char,Char) = CharCharCharCharCharTip | CharCharCharCharCharBin {-# UNPACK #-} !Size {-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char !(USet (Char,Char,Char,Char,Char)) !(USet (Char,Char,Char,Char,Char))
    view CharCharCharCharCharTip = Tip
    view (CharCharCharCharCharBin s a b c d e l r) = Bin s (a,b,c,d,e) l r
    tip = CharCharCharCharCharTip
    bin s (a,b,c,d,e) = CharCharCharCharCharBin s a b c d e

instance US (Char,Char,Char,Char,Char,Char) where
    data USet (Char,Char,Char,Char,Char,Char) = CharCharCharCharCharCharTip | CharCharCharCharCharCharBin {-# UNPACK #-} !Size {-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char !(USet (Char,Char,Char,Char,Char,Char)) !(USet (Char,Char,Char,Char,Char,Char))
    view CharCharCharCharCharCharTip = Tip
    view (CharCharCharCharCharCharBin s a b c d e f l r) = Bin s (a,b,c,d,e,f) l r
    tip = CharCharCharCharCharCharTip
    bin s (a,b,c,d,e,f) = CharCharCharCharCharCharBin s a b c d e f

instance US (Char,Char,Char,Char,Char,Char,Char) where
    data USet (Char,Char,Char,Char,Char,Char,Char) = CharCharCharCharCharCharCharTip | CharCharCharCharCharCharCharBin {-# UNPACK #-} !Size {-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char !(USet (Char,Char,Char,Char,Char,Char,Char)) !(USet (Char,Char,Char,Char,Char,Char,Char))
    view CharCharCharCharCharCharCharTip = Tip
    view (CharCharCharCharCharCharCharBin s a b c d e f g l r) = Bin s (a,b,c,d,e,f,g) l r
    tip = CharCharCharCharCharCharCharTip
    bin s (a,b,c,d,e,f,g) = CharCharCharCharCharCharCharBin s a b c d e f g

instance US (Char,Char,Char,Char,Char,Char,Char,Char) where
    data USet (Char,Char,Char,Char,Char,Char,Char,Char) = CharCharCharCharCharCharCharCharTip | CharCharCharCharCharCharCharCharBin {-# UNPACK #-} !Size {-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char !(USet (Char,Char,Char,Char,Char,Char,Char,Char)) !(USet (Char,Char,Char,Char,Char,Char,Char,Char))
    view CharCharCharCharCharCharCharCharTip = Tip
    view (CharCharCharCharCharCharCharCharBin s a b c d e f g h l r) = Bin s (a,b,c,d,e,f,g,h) l r
    tip = CharCharCharCharCharCharCharCharTip
    bin s (a,b,c,d,e,f,g,h) = CharCharCharCharCharCharCharCharBin s a b c d e f g h

instance US (Char,Char,Char,Char,Char,Char,Char,Char,Char) where
    data USet (Char,Char,Char,Char,Char,Char,Char,Char,Char) = CharCharCharCharCharCharCharCharCharTip | CharCharCharCharCharCharCharCharCharBin {-# UNPACK #-} !Size {-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char{-# UNPACK #-} !Char !(USet (Char,Char,Char,Char,Char,Char,Char,Char,Char)) !(USet (Char,Char,Char,Char,Char,Char,Char,Char,Char))
    view CharCharCharCharCharCharCharCharCharTip = Tip
    view (CharCharCharCharCharCharCharCharCharBin s a b c d e f g h i l r) = Bin s (a,b,c,d,e,f,g,h,i) l r
    tip = CharCharCharCharCharCharCharCharCharTip
    bin s (a,b,c,d,e,f,g,h,i) = CharCharCharCharCharCharCharCharCharBin s a b c d e f g h i

instance US (Int8,Int8) where
    data USet (Int8,Int8) = Int8Int8Tip | Int8Int8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int8{-# UNPACK #-} !Int8 !(USet (Int8,Int8)) !(USet (Int8,Int8))
    view Int8Int8Tip = Tip
    view (Int8Int8Bin s a b l r) = Bin s (a,b) l r
    tip = Int8Int8Tip
    bin s (a,b) = Int8Int8Bin s a b

instance US (Int8,Int8,Int8) where
    data USet (Int8,Int8,Int8) = Int8Int8Int8Tip | Int8Int8Int8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8 !(USet (Int8,Int8,Int8)) !(USet (Int8,Int8,Int8))
    view Int8Int8Int8Tip = Tip
    view (Int8Int8Int8Bin s a b c l r) = Bin s (a,b,c) l r
    tip = Int8Int8Int8Tip
    bin s (a,b,c) = Int8Int8Int8Bin s a b c

instance US (Int8,Int8,Int8,Int8) where
    data USet (Int8,Int8,Int8,Int8) = Int8Int8Int8Int8Tip | Int8Int8Int8Int8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8 !(USet (Int8,Int8,Int8,Int8)) !(USet (Int8,Int8,Int8,Int8))
    view Int8Int8Int8Int8Tip = Tip
    view (Int8Int8Int8Int8Bin s a b c d l r) = Bin s (a,b,c,d) l r
    tip = Int8Int8Int8Int8Tip
    bin s (a,b,c,d) = Int8Int8Int8Int8Bin s a b c d

instance US (Int8,Int8,Int8,Int8,Int8) where
    data USet (Int8,Int8,Int8,Int8,Int8) = Int8Int8Int8Int8Int8Tip | Int8Int8Int8Int8Int8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8 !(USet (Int8,Int8,Int8,Int8,Int8)) !(USet (Int8,Int8,Int8,Int8,Int8))
    view Int8Int8Int8Int8Int8Tip = Tip
    view (Int8Int8Int8Int8Int8Bin s a b c d e l r) = Bin s (a,b,c,d,e) l r
    tip = Int8Int8Int8Int8Int8Tip
    bin s (a,b,c,d,e) = Int8Int8Int8Int8Int8Bin s a b c d e

instance US (Int8,Int8,Int8,Int8,Int8,Int8) where
    data USet (Int8,Int8,Int8,Int8,Int8,Int8) = Int8Int8Int8Int8Int8Int8Tip | Int8Int8Int8Int8Int8Int8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8 !(USet (Int8,Int8,Int8,Int8,Int8,Int8)) !(USet (Int8,Int8,Int8,Int8,Int8,Int8))
    view Int8Int8Int8Int8Int8Int8Tip = Tip
    view (Int8Int8Int8Int8Int8Int8Bin s a b c d e f l r) = Bin s (a,b,c,d,e,f) l r
    tip = Int8Int8Int8Int8Int8Int8Tip
    bin s (a,b,c,d,e,f) = Int8Int8Int8Int8Int8Int8Bin s a b c d e f

instance US (Int8,Int8,Int8,Int8,Int8,Int8,Int8) where
    data USet (Int8,Int8,Int8,Int8,Int8,Int8,Int8) = Int8Int8Int8Int8Int8Int8Int8Tip | Int8Int8Int8Int8Int8Int8Int8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8 !(USet (Int8,Int8,Int8,Int8,Int8,Int8,Int8)) !(USet (Int8,Int8,Int8,Int8,Int8,Int8,Int8))
    view Int8Int8Int8Int8Int8Int8Int8Tip = Tip
    view (Int8Int8Int8Int8Int8Int8Int8Bin s a b c d e f g l r) = Bin s (a,b,c,d,e,f,g) l r
    tip = Int8Int8Int8Int8Int8Int8Int8Tip
    bin s (a,b,c,d,e,f,g) = Int8Int8Int8Int8Int8Int8Int8Bin s a b c d e f g

instance US (Int8,Int8,Int8,Int8,Int8,Int8,Int8,Int8) where
    data USet (Int8,Int8,Int8,Int8,Int8,Int8,Int8,Int8) = Int8Int8Int8Int8Int8Int8Int8Int8Tip | Int8Int8Int8Int8Int8Int8Int8Int8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8 !(USet (Int8,Int8,Int8,Int8,Int8,Int8,Int8,Int8)) !(USet (Int8,Int8,Int8,Int8,Int8,Int8,Int8,Int8))
    view Int8Int8Int8Int8Int8Int8Int8Int8Tip = Tip
    view (Int8Int8Int8Int8Int8Int8Int8Int8Bin s a b c d e f g h l r) = Bin s (a,b,c,d,e,f,g,h) l r
    tip = Int8Int8Int8Int8Int8Int8Int8Int8Tip
    bin s (a,b,c,d,e,f,g,h) = Int8Int8Int8Int8Int8Int8Int8Int8Bin s a b c d e f g h

instance US (Int8,Int8,Int8,Int8,Int8,Int8,Int8,Int8,Int8) where
    data USet (Int8,Int8,Int8,Int8,Int8,Int8,Int8,Int8,Int8) = Int8Int8Int8Int8Int8Int8Int8Int8Int8Tip | Int8Int8Int8Int8Int8Int8Int8Int8Int8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8{-# UNPACK #-} !Int8 !(USet (Int8,Int8,Int8,Int8,Int8,Int8,Int8,Int8,Int8)) !(USet (Int8,Int8,Int8,Int8,Int8,Int8,Int8,Int8,Int8))
    view Int8Int8Int8Int8Int8Int8Int8Int8Int8Tip = Tip
    view (Int8Int8Int8Int8Int8Int8Int8Int8Int8Bin s a b c d e f g h i l r) = Bin s (a,b,c,d,e,f,g,h,i) l r
    tip = Int8Int8Int8Int8Int8Int8Int8Int8Int8Tip
    bin s (a,b,c,d,e,f,g,h,i) = Int8Int8Int8Int8Int8Int8Int8Int8Int8Bin s a b c d e f g h i

instance US (Int16,Int16) where
    data USet (Int16,Int16) = Int16Int16Tip | Int16Int16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int16{-# UNPACK #-} !Int16 !(USet (Int16,Int16)) !(USet (Int16,Int16))
    view Int16Int16Tip = Tip
    view (Int16Int16Bin s a b l r) = Bin s (a,b) l r
    tip = Int16Int16Tip
    bin s (a,b) = Int16Int16Bin s a b

instance US (Int16,Int16,Int16) where
    data USet (Int16,Int16,Int16) = Int16Int16Int16Tip | Int16Int16Int16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16 !(USet (Int16,Int16,Int16)) !(USet (Int16,Int16,Int16))
    view Int16Int16Int16Tip = Tip
    view (Int16Int16Int16Bin s a b c l r) = Bin s (a,b,c) l r
    tip = Int16Int16Int16Tip
    bin s (a,b,c) = Int16Int16Int16Bin s a b c

instance US (Int16,Int16,Int16,Int16) where
    data USet (Int16,Int16,Int16,Int16) = Int16Int16Int16Int16Tip | Int16Int16Int16Int16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16 !(USet (Int16,Int16,Int16,Int16)) !(USet (Int16,Int16,Int16,Int16))
    view Int16Int16Int16Int16Tip = Tip
    view (Int16Int16Int16Int16Bin s a b c d l r) = Bin s (a,b,c,d) l r
    tip = Int16Int16Int16Int16Tip
    bin s (a,b,c,d) = Int16Int16Int16Int16Bin s a b c d

instance US (Int16,Int16,Int16,Int16,Int16) where
    data USet (Int16,Int16,Int16,Int16,Int16) = Int16Int16Int16Int16Int16Tip | Int16Int16Int16Int16Int16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16 !(USet (Int16,Int16,Int16,Int16,Int16)) !(USet (Int16,Int16,Int16,Int16,Int16))
    view Int16Int16Int16Int16Int16Tip = Tip
    view (Int16Int16Int16Int16Int16Bin s a b c d e l r) = Bin s (a,b,c,d,e) l r
    tip = Int16Int16Int16Int16Int16Tip
    bin s (a,b,c,d,e) = Int16Int16Int16Int16Int16Bin s a b c d e

instance US (Int16,Int16,Int16,Int16,Int16,Int16) where
    data USet (Int16,Int16,Int16,Int16,Int16,Int16) = Int16Int16Int16Int16Int16Int16Tip | Int16Int16Int16Int16Int16Int16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16 !(USet (Int16,Int16,Int16,Int16,Int16,Int16)) !(USet (Int16,Int16,Int16,Int16,Int16,Int16))
    view Int16Int16Int16Int16Int16Int16Tip = Tip
    view (Int16Int16Int16Int16Int16Int16Bin s a b c d e f l r) = Bin s (a,b,c,d,e,f) l r
    tip = Int16Int16Int16Int16Int16Int16Tip
    bin s (a,b,c,d,e,f) = Int16Int16Int16Int16Int16Int16Bin s a b c d e f

instance US (Int16,Int16,Int16,Int16,Int16,Int16,Int16) where
    data USet (Int16,Int16,Int16,Int16,Int16,Int16,Int16) = Int16Int16Int16Int16Int16Int16Int16Tip | Int16Int16Int16Int16Int16Int16Int16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16 !(USet (Int16,Int16,Int16,Int16,Int16,Int16,Int16)) !(USet (Int16,Int16,Int16,Int16,Int16,Int16,Int16))
    view Int16Int16Int16Int16Int16Int16Int16Tip = Tip
    view (Int16Int16Int16Int16Int16Int16Int16Bin s a b c d e f g l r) = Bin s (a,b,c,d,e,f,g) l r
    tip = Int16Int16Int16Int16Int16Int16Int16Tip
    bin s (a,b,c,d,e,f,g) = Int16Int16Int16Int16Int16Int16Int16Bin s a b c d e f g

instance US (Int16,Int16,Int16,Int16,Int16,Int16,Int16,Int16) where
    data USet (Int16,Int16,Int16,Int16,Int16,Int16,Int16,Int16) = Int16Int16Int16Int16Int16Int16Int16Int16Tip | Int16Int16Int16Int16Int16Int16Int16Int16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16 !(USet (Int16,Int16,Int16,Int16,Int16,Int16,Int16,Int16)) !(USet (Int16,Int16,Int16,Int16,Int16,Int16,Int16,Int16))
    view Int16Int16Int16Int16Int16Int16Int16Int16Tip = Tip
    view (Int16Int16Int16Int16Int16Int16Int16Int16Bin s a b c d e f g h l r) = Bin s (a,b,c,d,e,f,g,h) l r
    tip = Int16Int16Int16Int16Int16Int16Int16Int16Tip
    bin s (a,b,c,d,e,f,g,h) = Int16Int16Int16Int16Int16Int16Int16Int16Bin s a b c d e f g h

instance US (Int16,Int16,Int16,Int16,Int16,Int16,Int16,Int16,Int16) where
    data USet (Int16,Int16,Int16,Int16,Int16,Int16,Int16,Int16,Int16) = Int16Int16Int16Int16Int16Int16Int16Int16Int16Tip | Int16Int16Int16Int16Int16Int16Int16Int16Int16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16{-# UNPACK #-} !Int16 !(USet (Int16,Int16,Int16,Int16,Int16,Int16,Int16,Int16,Int16)) !(USet (Int16,Int16,Int16,Int16,Int16,Int16,Int16,Int16,Int16))
    view Int16Int16Int16Int16Int16Int16Int16Int16Int16Tip = Tip
    view (Int16Int16Int16Int16Int16Int16Int16Int16Int16Bin s a b c d e f g h i l r) = Bin s (a,b,c,d,e,f,g,h,i) l r
    tip = Int16Int16Int16Int16Int16Int16Int16Int16Int16Tip
    bin s (a,b,c,d,e,f,g,h,i) = Int16Int16Int16Int16Int16Int16Int16Int16Int16Bin s a b c d e f g h i

instance US (Int32,Int32) where
    data USet (Int32,Int32) = Int32Int32Tip | Int32Int32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int32{-# UNPACK #-} !Int32 !(USet (Int32,Int32)) !(USet (Int32,Int32))
    view Int32Int32Tip = Tip
    view (Int32Int32Bin s a b l r) = Bin s (a,b) l r
    tip = Int32Int32Tip
    bin s (a,b) = Int32Int32Bin s a b

instance US (Int32,Int32,Int32) where
    data USet (Int32,Int32,Int32) = Int32Int32Int32Tip | Int32Int32Int32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32 !(USet (Int32,Int32,Int32)) !(USet (Int32,Int32,Int32))
    view Int32Int32Int32Tip = Tip
    view (Int32Int32Int32Bin s a b c l r) = Bin s (a,b,c) l r
    tip = Int32Int32Int32Tip
    bin s (a,b,c) = Int32Int32Int32Bin s a b c

instance US (Int32,Int32,Int32,Int32) where
    data USet (Int32,Int32,Int32,Int32) = Int32Int32Int32Int32Tip | Int32Int32Int32Int32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32 !(USet (Int32,Int32,Int32,Int32)) !(USet (Int32,Int32,Int32,Int32))
    view Int32Int32Int32Int32Tip = Tip
    view (Int32Int32Int32Int32Bin s a b c d l r) = Bin s (a,b,c,d) l r
    tip = Int32Int32Int32Int32Tip
    bin s (a,b,c,d) = Int32Int32Int32Int32Bin s a b c d

instance US (Int32,Int32,Int32,Int32,Int32) where
    data USet (Int32,Int32,Int32,Int32,Int32) = Int32Int32Int32Int32Int32Tip | Int32Int32Int32Int32Int32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32 !(USet (Int32,Int32,Int32,Int32,Int32)) !(USet (Int32,Int32,Int32,Int32,Int32))
    view Int32Int32Int32Int32Int32Tip = Tip
    view (Int32Int32Int32Int32Int32Bin s a b c d e l r) = Bin s (a,b,c,d,e) l r
    tip = Int32Int32Int32Int32Int32Tip
    bin s (a,b,c,d,e) = Int32Int32Int32Int32Int32Bin s a b c d e

instance US (Int32,Int32,Int32,Int32,Int32,Int32) where
    data USet (Int32,Int32,Int32,Int32,Int32,Int32) = Int32Int32Int32Int32Int32Int32Tip | Int32Int32Int32Int32Int32Int32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32 !(USet (Int32,Int32,Int32,Int32,Int32,Int32)) !(USet (Int32,Int32,Int32,Int32,Int32,Int32))
    view Int32Int32Int32Int32Int32Int32Tip = Tip
    view (Int32Int32Int32Int32Int32Int32Bin s a b c d e f l r) = Bin s (a,b,c,d,e,f) l r
    tip = Int32Int32Int32Int32Int32Int32Tip
    bin s (a,b,c,d,e,f) = Int32Int32Int32Int32Int32Int32Bin s a b c d e f

instance US (Int32,Int32,Int32,Int32,Int32,Int32,Int32) where
    data USet (Int32,Int32,Int32,Int32,Int32,Int32,Int32) = Int32Int32Int32Int32Int32Int32Int32Tip | Int32Int32Int32Int32Int32Int32Int32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32 !(USet (Int32,Int32,Int32,Int32,Int32,Int32,Int32)) !(USet (Int32,Int32,Int32,Int32,Int32,Int32,Int32))
    view Int32Int32Int32Int32Int32Int32Int32Tip = Tip
    view (Int32Int32Int32Int32Int32Int32Int32Bin s a b c d e f g l r) = Bin s (a,b,c,d,e,f,g) l r
    tip = Int32Int32Int32Int32Int32Int32Int32Tip
    bin s (a,b,c,d,e,f,g) = Int32Int32Int32Int32Int32Int32Int32Bin s a b c d e f g

instance US (Int32,Int32,Int32,Int32,Int32,Int32,Int32,Int32) where
    data USet (Int32,Int32,Int32,Int32,Int32,Int32,Int32,Int32) = Int32Int32Int32Int32Int32Int32Int32Int32Tip | Int32Int32Int32Int32Int32Int32Int32Int32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32 !(USet (Int32,Int32,Int32,Int32,Int32,Int32,Int32,Int32)) !(USet (Int32,Int32,Int32,Int32,Int32,Int32,Int32,Int32))
    view Int32Int32Int32Int32Int32Int32Int32Int32Tip = Tip
    view (Int32Int32Int32Int32Int32Int32Int32Int32Bin s a b c d e f g h l r) = Bin s (a,b,c,d,e,f,g,h) l r
    tip = Int32Int32Int32Int32Int32Int32Int32Int32Tip
    bin s (a,b,c,d,e,f,g,h) = Int32Int32Int32Int32Int32Int32Int32Int32Bin s a b c d e f g h

instance US (Int32,Int32,Int32,Int32,Int32,Int32,Int32,Int32,Int32) where
    data USet (Int32,Int32,Int32,Int32,Int32,Int32,Int32,Int32,Int32) = Int32Int32Int32Int32Int32Int32Int32Int32Int32Tip | Int32Int32Int32Int32Int32Int32Int32Int32Int32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32{-# UNPACK #-} !Int32 !(USet (Int32,Int32,Int32,Int32,Int32,Int32,Int32,Int32,Int32)) !(USet (Int32,Int32,Int32,Int32,Int32,Int32,Int32,Int32,Int32))
    view Int32Int32Int32Int32Int32Int32Int32Int32Int32Tip = Tip
    view (Int32Int32Int32Int32Int32Int32Int32Int32Int32Bin s a b c d e f g h i l r) = Bin s (a,b,c,d,e,f,g,h,i) l r
    tip = Int32Int32Int32Int32Int32Int32Int32Int32Int32Tip
    bin s (a,b,c,d,e,f,g,h,i) = Int32Int32Int32Int32Int32Int32Int32Int32Int32Bin s a b c d e f g h i

instance US (Int64,Int64) where
    data USet (Int64,Int64) = Int64Int64Tip | Int64Int64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int64{-# UNPACK #-} !Int64 !(USet (Int64,Int64)) !(USet (Int64,Int64))
    view Int64Int64Tip = Tip
    view (Int64Int64Bin s a b l r) = Bin s (a,b) l r
    tip = Int64Int64Tip
    bin s (a,b) = Int64Int64Bin s a b

instance US (Int64,Int64,Int64) where
    data USet (Int64,Int64,Int64) = Int64Int64Int64Tip | Int64Int64Int64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64 !(USet (Int64,Int64,Int64)) !(USet (Int64,Int64,Int64))
    view Int64Int64Int64Tip = Tip
    view (Int64Int64Int64Bin s a b c l r) = Bin s (a,b,c) l r
    tip = Int64Int64Int64Tip
    bin s (a,b,c) = Int64Int64Int64Bin s a b c

instance US (Int64,Int64,Int64,Int64) where
    data USet (Int64,Int64,Int64,Int64) = Int64Int64Int64Int64Tip | Int64Int64Int64Int64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64 !(USet (Int64,Int64,Int64,Int64)) !(USet (Int64,Int64,Int64,Int64))
    view Int64Int64Int64Int64Tip = Tip
    view (Int64Int64Int64Int64Bin s a b c d l r) = Bin s (a,b,c,d) l r
    tip = Int64Int64Int64Int64Tip
    bin s (a,b,c,d) = Int64Int64Int64Int64Bin s a b c d

instance US (Int64,Int64,Int64,Int64,Int64) where
    data USet (Int64,Int64,Int64,Int64,Int64) = Int64Int64Int64Int64Int64Tip | Int64Int64Int64Int64Int64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64 !(USet (Int64,Int64,Int64,Int64,Int64)) !(USet (Int64,Int64,Int64,Int64,Int64))
    view Int64Int64Int64Int64Int64Tip = Tip
    view (Int64Int64Int64Int64Int64Bin s a b c d e l r) = Bin s (a,b,c,d,e) l r
    tip = Int64Int64Int64Int64Int64Tip
    bin s (a,b,c,d,e) = Int64Int64Int64Int64Int64Bin s a b c d e

instance US (Int64,Int64,Int64,Int64,Int64,Int64) where
    data USet (Int64,Int64,Int64,Int64,Int64,Int64) = Int64Int64Int64Int64Int64Int64Tip | Int64Int64Int64Int64Int64Int64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64 !(USet (Int64,Int64,Int64,Int64,Int64,Int64)) !(USet (Int64,Int64,Int64,Int64,Int64,Int64))
    view Int64Int64Int64Int64Int64Int64Tip = Tip
    view (Int64Int64Int64Int64Int64Int64Bin s a b c d e f l r) = Bin s (a,b,c,d,e,f) l r
    tip = Int64Int64Int64Int64Int64Int64Tip
    bin s (a,b,c,d,e,f) = Int64Int64Int64Int64Int64Int64Bin s a b c d e f

instance US (Int64,Int64,Int64,Int64,Int64,Int64,Int64) where
    data USet (Int64,Int64,Int64,Int64,Int64,Int64,Int64) = Int64Int64Int64Int64Int64Int64Int64Tip | Int64Int64Int64Int64Int64Int64Int64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64 !(USet (Int64,Int64,Int64,Int64,Int64,Int64,Int64)) !(USet (Int64,Int64,Int64,Int64,Int64,Int64,Int64))
    view Int64Int64Int64Int64Int64Int64Int64Tip = Tip
    view (Int64Int64Int64Int64Int64Int64Int64Bin s a b c d e f g l r) = Bin s (a,b,c,d,e,f,g) l r
    tip = Int64Int64Int64Int64Int64Int64Int64Tip
    bin s (a,b,c,d,e,f,g) = Int64Int64Int64Int64Int64Int64Int64Bin s a b c d e f g

instance US (Int64,Int64,Int64,Int64,Int64,Int64,Int64,Int64) where
    data USet (Int64,Int64,Int64,Int64,Int64,Int64,Int64,Int64) = Int64Int64Int64Int64Int64Int64Int64Int64Tip | Int64Int64Int64Int64Int64Int64Int64Int64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64 !(USet (Int64,Int64,Int64,Int64,Int64,Int64,Int64,Int64)) !(USet (Int64,Int64,Int64,Int64,Int64,Int64,Int64,Int64))
    view Int64Int64Int64Int64Int64Int64Int64Int64Tip = Tip
    view (Int64Int64Int64Int64Int64Int64Int64Int64Bin s a b c d e f g h l r) = Bin s (a,b,c,d,e,f,g,h) l r
    tip = Int64Int64Int64Int64Int64Int64Int64Int64Tip
    bin s (a,b,c,d,e,f,g,h) = Int64Int64Int64Int64Int64Int64Int64Int64Bin s a b c d e f g h

instance US (Int64,Int64,Int64,Int64,Int64,Int64,Int64,Int64,Int64) where
    data USet (Int64,Int64,Int64,Int64,Int64,Int64,Int64,Int64,Int64) = Int64Int64Int64Int64Int64Int64Int64Int64Int64Tip | Int64Int64Int64Int64Int64Int64Int64Int64Int64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64{-# UNPACK #-} !Int64 !(USet (Int64,Int64,Int64,Int64,Int64,Int64,Int64,Int64,Int64)) !(USet (Int64,Int64,Int64,Int64,Int64,Int64,Int64,Int64,Int64))
    view Int64Int64Int64Int64Int64Int64Int64Int64Int64Tip = Tip
    view (Int64Int64Int64Int64Int64Int64Int64Int64Int64Bin s a b c d e f g h i l r) = Bin s (a,b,c,d,e,f,g,h,i) l r
    tip = Int64Int64Int64Int64Int64Int64Int64Int64Int64Tip
    bin s (a,b,c,d,e,f,g,h,i) = Int64Int64Int64Int64Int64Int64Int64Int64Int64Bin s a b c d e f g h i

instance US (Word8,Word8) where
    data USet (Word8,Word8) = Word8Word8Tip | Word8Word8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word8{-# UNPACK #-} !Word8 !(USet (Word8,Word8)) !(USet (Word8,Word8))
    view Word8Word8Tip = Tip
    view (Word8Word8Bin s a b l r) = Bin s (a,b) l r
    tip = Word8Word8Tip
    bin s (a,b) = Word8Word8Bin s a b

instance US (Word8,Word8,Word8) where
    data USet (Word8,Word8,Word8) = Word8Word8Word8Tip | Word8Word8Word8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8 !(USet (Word8,Word8,Word8)) !(USet (Word8,Word8,Word8))
    view Word8Word8Word8Tip = Tip
    view (Word8Word8Word8Bin s a b c l r) = Bin s (a,b,c) l r
    tip = Word8Word8Word8Tip
    bin s (a,b,c) = Word8Word8Word8Bin s a b c

instance US (Word8,Word8,Word8,Word8) where
    data USet (Word8,Word8,Word8,Word8) = Word8Word8Word8Word8Tip | Word8Word8Word8Word8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8 !(USet (Word8,Word8,Word8,Word8)) !(USet (Word8,Word8,Word8,Word8))
    view Word8Word8Word8Word8Tip = Tip
    view (Word8Word8Word8Word8Bin s a b c d l r) = Bin s (a,b,c,d) l r
    tip = Word8Word8Word8Word8Tip
    bin s (a,b,c,d) = Word8Word8Word8Word8Bin s a b c d

instance US (Word8,Word8,Word8,Word8,Word8) where
    data USet (Word8,Word8,Word8,Word8,Word8) = Word8Word8Word8Word8Word8Tip | Word8Word8Word8Word8Word8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8 !(USet (Word8,Word8,Word8,Word8,Word8)) !(USet (Word8,Word8,Word8,Word8,Word8))
    view Word8Word8Word8Word8Word8Tip = Tip
    view (Word8Word8Word8Word8Word8Bin s a b c d e l r) = Bin s (a,b,c,d,e) l r
    tip = Word8Word8Word8Word8Word8Tip
    bin s (a,b,c,d,e) = Word8Word8Word8Word8Word8Bin s a b c d e

instance US (Word8,Word8,Word8,Word8,Word8,Word8) where
    data USet (Word8,Word8,Word8,Word8,Word8,Word8) = Word8Word8Word8Word8Word8Word8Tip | Word8Word8Word8Word8Word8Word8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8 !(USet (Word8,Word8,Word8,Word8,Word8,Word8)) !(USet (Word8,Word8,Word8,Word8,Word8,Word8))
    view Word8Word8Word8Word8Word8Word8Tip = Tip
    view (Word8Word8Word8Word8Word8Word8Bin s a b c d e f l r) = Bin s (a,b,c,d,e,f) l r
    tip = Word8Word8Word8Word8Word8Word8Tip
    bin s (a,b,c,d,e,f) = Word8Word8Word8Word8Word8Word8Bin s a b c d e f

instance US (Word8,Word8,Word8,Word8,Word8,Word8,Word8) where
    data USet (Word8,Word8,Word8,Word8,Word8,Word8,Word8) = Word8Word8Word8Word8Word8Word8Word8Tip | Word8Word8Word8Word8Word8Word8Word8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8 !(USet (Word8,Word8,Word8,Word8,Word8,Word8,Word8)) !(USet (Word8,Word8,Word8,Word8,Word8,Word8,Word8))
    view Word8Word8Word8Word8Word8Word8Word8Tip = Tip
    view (Word8Word8Word8Word8Word8Word8Word8Bin s a b c d e f g l r) = Bin s (a,b,c,d,e,f,g) l r
    tip = Word8Word8Word8Word8Word8Word8Word8Tip
    bin s (a,b,c,d,e,f,g) = Word8Word8Word8Word8Word8Word8Word8Bin s a b c d e f g

instance US (Word8,Word8,Word8,Word8,Word8,Word8,Word8,Word8) where
    data USet (Word8,Word8,Word8,Word8,Word8,Word8,Word8,Word8) = Word8Word8Word8Word8Word8Word8Word8Word8Tip | Word8Word8Word8Word8Word8Word8Word8Word8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8 !(USet (Word8,Word8,Word8,Word8,Word8,Word8,Word8,Word8)) !(USet (Word8,Word8,Word8,Word8,Word8,Word8,Word8,Word8))
    view Word8Word8Word8Word8Word8Word8Word8Word8Tip = Tip
    view (Word8Word8Word8Word8Word8Word8Word8Word8Bin s a b c d e f g h l r) = Bin s (a,b,c,d,e,f,g,h) l r
    tip = Word8Word8Word8Word8Word8Word8Word8Word8Tip
    bin s (a,b,c,d,e,f,g,h) = Word8Word8Word8Word8Word8Word8Word8Word8Bin s a b c d e f g h

instance US (Word8,Word8,Word8,Word8,Word8,Word8,Word8,Word8,Word8) where
    data USet (Word8,Word8,Word8,Word8,Word8,Word8,Word8,Word8,Word8) = Word8Word8Word8Word8Word8Word8Word8Word8Word8Tip | Word8Word8Word8Word8Word8Word8Word8Word8Word8Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8{-# UNPACK #-} !Word8 !(USet (Word8,Word8,Word8,Word8,Word8,Word8,Word8,Word8,Word8)) !(USet (Word8,Word8,Word8,Word8,Word8,Word8,Word8,Word8,Word8))
    view Word8Word8Word8Word8Word8Word8Word8Word8Word8Tip = Tip
    view (Word8Word8Word8Word8Word8Word8Word8Word8Word8Bin s a b c d e f g h i l r) = Bin s (a,b,c,d,e,f,g,h,i) l r
    tip = Word8Word8Word8Word8Word8Word8Word8Word8Word8Tip
    bin s (a,b,c,d,e,f,g,h,i) = Word8Word8Word8Word8Word8Word8Word8Word8Word8Bin s a b c d e f g h i

instance US (Word16,Word16) where
    data USet (Word16,Word16) = Word16Word16Tip | Word16Word16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word16{-# UNPACK #-} !Word16 !(USet (Word16,Word16)) !(USet (Word16,Word16))
    view Word16Word16Tip = Tip
    view (Word16Word16Bin s a b l r) = Bin s (a,b) l r
    tip = Word16Word16Tip
    bin s (a,b) = Word16Word16Bin s a b

instance US (Word16,Word16,Word16) where
    data USet (Word16,Word16,Word16) = Word16Word16Word16Tip | Word16Word16Word16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16 !(USet (Word16,Word16,Word16)) !(USet (Word16,Word16,Word16))
    view Word16Word16Word16Tip = Tip
    view (Word16Word16Word16Bin s a b c l r) = Bin s (a,b,c) l r
    tip = Word16Word16Word16Tip
    bin s (a,b,c) = Word16Word16Word16Bin s a b c

instance US (Word16,Word16,Word16,Word16) where
    data USet (Word16,Word16,Word16,Word16) = Word16Word16Word16Word16Tip | Word16Word16Word16Word16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16 !(USet (Word16,Word16,Word16,Word16)) !(USet (Word16,Word16,Word16,Word16))
    view Word16Word16Word16Word16Tip = Tip
    view (Word16Word16Word16Word16Bin s a b c d l r) = Bin s (a,b,c,d) l r
    tip = Word16Word16Word16Word16Tip
    bin s (a,b,c,d) = Word16Word16Word16Word16Bin s a b c d

instance US (Word16,Word16,Word16,Word16,Word16) where
    data USet (Word16,Word16,Word16,Word16,Word16) = Word16Word16Word16Word16Word16Tip | Word16Word16Word16Word16Word16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16 !(USet (Word16,Word16,Word16,Word16,Word16)) !(USet (Word16,Word16,Word16,Word16,Word16))
    view Word16Word16Word16Word16Word16Tip = Tip
    view (Word16Word16Word16Word16Word16Bin s a b c d e l r) = Bin s (a,b,c,d,e) l r
    tip = Word16Word16Word16Word16Word16Tip
    bin s (a,b,c,d,e) = Word16Word16Word16Word16Word16Bin s a b c d e

instance US (Word16,Word16,Word16,Word16,Word16,Word16) where
    data USet (Word16,Word16,Word16,Word16,Word16,Word16) = Word16Word16Word16Word16Word16Word16Tip | Word16Word16Word16Word16Word16Word16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16 !(USet (Word16,Word16,Word16,Word16,Word16,Word16)) !(USet (Word16,Word16,Word16,Word16,Word16,Word16))
    view Word16Word16Word16Word16Word16Word16Tip = Tip
    view (Word16Word16Word16Word16Word16Word16Bin s a b c d e f l r) = Bin s (a,b,c,d,e,f) l r
    tip = Word16Word16Word16Word16Word16Word16Tip
    bin s (a,b,c,d,e,f) = Word16Word16Word16Word16Word16Word16Bin s a b c d e f

instance US (Word16,Word16,Word16,Word16,Word16,Word16,Word16) where
    data USet (Word16,Word16,Word16,Word16,Word16,Word16,Word16) = Word16Word16Word16Word16Word16Word16Word16Tip | Word16Word16Word16Word16Word16Word16Word16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16 !(USet (Word16,Word16,Word16,Word16,Word16,Word16,Word16)) !(USet (Word16,Word16,Word16,Word16,Word16,Word16,Word16))
    view Word16Word16Word16Word16Word16Word16Word16Tip = Tip
    view (Word16Word16Word16Word16Word16Word16Word16Bin s a b c d e f g l r) = Bin s (a,b,c,d,e,f,g) l r
    tip = Word16Word16Word16Word16Word16Word16Word16Tip
    bin s (a,b,c,d,e,f,g) = Word16Word16Word16Word16Word16Word16Word16Bin s a b c d e f g

instance US (Word16,Word16,Word16,Word16,Word16,Word16,Word16,Word16) where
    data USet (Word16,Word16,Word16,Word16,Word16,Word16,Word16,Word16) = Word16Word16Word16Word16Word16Word16Word16Word16Tip | Word16Word16Word16Word16Word16Word16Word16Word16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16 !(USet (Word16,Word16,Word16,Word16,Word16,Word16,Word16,Word16)) !(USet (Word16,Word16,Word16,Word16,Word16,Word16,Word16,Word16))
    view Word16Word16Word16Word16Word16Word16Word16Word16Tip = Tip
    view (Word16Word16Word16Word16Word16Word16Word16Word16Bin s a b c d e f g h l r) = Bin s (a,b,c,d,e,f,g,h) l r
    tip = Word16Word16Word16Word16Word16Word16Word16Word16Tip
    bin s (a,b,c,d,e,f,g,h) = Word16Word16Word16Word16Word16Word16Word16Word16Bin s a b c d e f g h

instance US (Word16,Word16,Word16,Word16,Word16,Word16,Word16,Word16,Word16) where
    data USet (Word16,Word16,Word16,Word16,Word16,Word16,Word16,Word16,Word16) = Word16Word16Word16Word16Word16Word16Word16Word16Word16Tip | Word16Word16Word16Word16Word16Word16Word16Word16Word16Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16{-# UNPACK #-} !Word16 !(USet (Word16,Word16,Word16,Word16,Word16,Word16,Word16,Word16,Word16)) !(USet (Word16,Word16,Word16,Word16,Word16,Word16,Word16,Word16,Word16))
    view Word16Word16Word16Word16Word16Word16Word16Word16Word16Tip = Tip
    view (Word16Word16Word16Word16Word16Word16Word16Word16Word16Bin s a b c d e f g h i l r) = Bin s (a,b,c,d,e,f,g,h,i) l r
    tip = Word16Word16Word16Word16Word16Word16Word16Word16Word16Tip
    bin s (a,b,c,d,e,f,g,h,i) = Word16Word16Word16Word16Word16Word16Word16Word16Word16Bin s a b c d e f g h i

instance US (Word32,Word32) where
    data USet (Word32,Word32) = Word32Word32Tip | Word32Word32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word32{-# UNPACK #-} !Word32 !(USet (Word32,Word32)) !(USet (Word32,Word32))
    view Word32Word32Tip = Tip
    view (Word32Word32Bin s a b l r) = Bin s (a,b) l r
    tip = Word32Word32Tip
    bin s (a,b) = Word32Word32Bin s a b

instance US (Word32,Word32,Word32) where
    data USet (Word32,Word32,Word32) = Word32Word32Word32Tip | Word32Word32Word32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32 !(USet (Word32,Word32,Word32)) !(USet (Word32,Word32,Word32))
    view Word32Word32Word32Tip = Tip
    view (Word32Word32Word32Bin s a b c l r) = Bin s (a,b,c) l r
    tip = Word32Word32Word32Tip
    bin s (a,b,c) = Word32Word32Word32Bin s a b c

instance US (Word32,Word32,Word32,Word32) where
    data USet (Word32,Word32,Word32,Word32) = Word32Word32Word32Word32Tip | Word32Word32Word32Word32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32 !(USet (Word32,Word32,Word32,Word32)) !(USet (Word32,Word32,Word32,Word32))
    view Word32Word32Word32Word32Tip = Tip
    view (Word32Word32Word32Word32Bin s a b c d l r) = Bin s (a,b,c,d) l r
    tip = Word32Word32Word32Word32Tip
    bin s (a,b,c,d) = Word32Word32Word32Word32Bin s a b c d

instance US (Word32,Word32,Word32,Word32,Word32) where
    data USet (Word32,Word32,Word32,Word32,Word32) = Word32Word32Word32Word32Word32Tip | Word32Word32Word32Word32Word32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32 !(USet (Word32,Word32,Word32,Word32,Word32)) !(USet (Word32,Word32,Word32,Word32,Word32))
    view Word32Word32Word32Word32Word32Tip = Tip
    view (Word32Word32Word32Word32Word32Bin s a b c d e l r) = Bin s (a,b,c,d,e) l r
    tip = Word32Word32Word32Word32Word32Tip
    bin s (a,b,c,d,e) = Word32Word32Word32Word32Word32Bin s a b c d e

instance US (Word32,Word32,Word32,Word32,Word32,Word32) where
    data USet (Word32,Word32,Word32,Word32,Word32,Word32) = Word32Word32Word32Word32Word32Word32Tip | Word32Word32Word32Word32Word32Word32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32 !(USet (Word32,Word32,Word32,Word32,Word32,Word32)) !(USet (Word32,Word32,Word32,Word32,Word32,Word32))
    view Word32Word32Word32Word32Word32Word32Tip = Tip
    view (Word32Word32Word32Word32Word32Word32Bin s a b c d e f l r) = Bin s (a,b,c,d,e,f) l r
    tip = Word32Word32Word32Word32Word32Word32Tip
    bin s (a,b,c,d,e,f) = Word32Word32Word32Word32Word32Word32Bin s a b c d e f

instance US (Word32,Word32,Word32,Word32,Word32,Word32,Word32) where
    data USet (Word32,Word32,Word32,Word32,Word32,Word32,Word32) = Word32Word32Word32Word32Word32Word32Word32Tip | Word32Word32Word32Word32Word32Word32Word32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32 !(USet (Word32,Word32,Word32,Word32,Word32,Word32,Word32)) !(USet (Word32,Word32,Word32,Word32,Word32,Word32,Word32))
    view Word32Word32Word32Word32Word32Word32Word32Tip = Tip
    view (Word32Word32Word32Word32Word32Word32Word32Bin s a b c d e f g l r) = Bin s (a,b,c,d,e,f,g) l r
    tip = Word32Word32Word32Word32Word32Word32Word32Tip
    bin s (a,b,c,d,e,f,g) = Word32Word32Word32Word32Word32Word32Word32Bin s a b c d e f g

instance US (Word32,Word32,Word32,Word32,Word32,Word32,Word32,Word32) where
    data USet (Word32,Word32,Word32,Word32,Word32,Word32,Word32,Word32) = Word32Word32Word32Word32Word32Word32Word32Word32Tip | Word32Word32Word32Word32Word32Word32Word32Word32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32 !(USet (Word32,Word32,Word32,Word32,Word32,Word32,Word32,Word32)) !(USet (Word32,Word32,Word32,Word32,Word32,Word32,Word32,Word32))
    view Word32Word32Word32Word32Word32Word32Word32Word32Tip = Tip
    view (Word32Word32Word32Word32Word32Word32Word32Word32Bin s a b c d e f g h l r) = Bin s (a,b,c,d,e,f,g,h) l r
    tip = Word32Word32Word32Word32Word32Word32Word32Word32Tip
    bin s (a,b,c,d,e,f,g,h) = Word32Word32Word32Word32Word32Word32Word32Word32Bin s a b c d e f g h

instance US (Word32,Word32,Word32,Word32,Word32,Word32,Word32,Word32,Word32) where
    data USet (Word32,Word32,Word32,Word32,Word32,Word32,Word32,Word32,Word32) = Word32Word32Word32Word32Word32Word32Word32Word32Word32Tip | Word32Word32Word32Word32Word32Word32Word32Word32Word32Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32{-# UNPACK #-} !Word32 !(USet (Word32,Word32,Word32,Word32,Word32,Word32,Word32,Word32,Word32)) !(USet (Word32,Word32,Word32,Word32,Word32,Word32,Word32,Word32,Word32))
    view Word32Word32Word32Word32Word32Word32Word32Word32Word32Tip = Tip
    view (Word32Word32Word32Word32Word32Word32Word32Word32Word32Bin s a b c d e f g h i l r) = Bin s (a,b,c,d,e,f,g,h,i) l r
    tip = Word32Word32Word32Word32Word32Word32Word32Word32Word32Tip
    bin s (a,b,c,d,e,f,g,h,i) = Word32Word32Word32Word32Word32Word32Word32Word32Word32Bin s a b c d e f g h i

instance US (Word64,Word64) where
    data USet (Word64,Word64) = Word64Word64Tip | Word64Word64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word64{-# UNPACK #-} !Word64 !(USet (Word64,Word64)) !(USet (Word64,Word64))
    view Word64Word64Tip = Tip
    view (Word64Word64Bin s a b l r) = Bin s (a,b) l r
    tip = Word64Word64Tip
    bin s (a,b) = Word64Word64Bin s a b

instance US (Word64,Word64,Word64) where
    data USet (Word64,Word64,Word64) = Word64Word64Word64Tip | Word64Word64Word64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64 !(USet (Word64,Word64,Word64)) !(USet (Word64,Word64,Word64))
    view Word64Word64Word64Tip = Tip
    view (Word64Word64Word64Bin s a b c l r) = Bin s (a,b,c) l r
    tip = Word64Word64Word64Tip
    bin s (a,b,c) = Word64Word64Word64Bin s a b c

instance US (Word64,Word64,Word64,Word64) where
    data USet (Word64,Word64,Word64,Word64) = Word64Word64Word64Word64Tip | Word64Word64Word64Word64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64 !(USet (Word64,Word64,Word64,Word64)) !(USet (Word64,Word64,Word64,Word64))
    view Word64Word64Word64Word64Tip = Tip
    view (Word64Word64Word64Word64Bin s a b c d l r) = Bin s (a,b,c,d) l r
    tip = Word64Word64Word64Word64Tip
    bin s (a,b,c,d) = Word64Word64Word64Word64Bin s a b c d

instance US (Word64,Word64,Word64,Word64,Word64) where
    data USet (Word64,Word64,Word64,Word64,Word64) = Word64Word64Word64Word64Word64Tip | Word64Word64Word64Word64Word64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64 !(USet (Word64,Word64,Word64,Word64,Word64)) !(USet (Word64,Word64,Word64,Word64,Word64))
    view Word64Word64Word64Word64Word64Tip = Tip
    view (Word64Word64Word64Word64Word64Bin s a b c d e l r) = Bin s (a,b,c,d,e) l r
    tip = Word64Word64Word64Word64Word64Tip
    bin s (a,b,c,d,e) = Word64Word64Word64Word64Word64Bin s a b c d e

instance US (Word64,Word64,Word64,Word64,Word64,Word64) where
    data USet (Word64,Word64,Word64,Word64,Word64,Word64) = Word64Word64Word64Word64Word64Word64Tip | Word64Word64Word64Word64Word64Word64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64 !(USet (Word64,Word64,Word64,Word64,Word64,Word64)) !(USet (Word64,Word64,Word64,Word64,Word64,Word64))
    view Word64Word64Word64Word64Word64Word64Tip = Tip
    view (Word64Word64Word64Word64Word64Word64Bin s a b c d e f l r) = Bin s (a,b,c,d,e,f) l r
    tip = Word64Word64Word64Word64Word64Word64Tip
    bin s (a,b,c,d,e,f) = Word64Word64Word64Word64Word64Word64Bin s a b c d e f

instance US (Word64,Word64,Word64,Word64,Word64,Word64,Word64) where
    data USet (Word64,Word64,Word64,Word64,Word64,Word64,Word64) = Word64Word64Word64Word64Word64Word64Word64Tip | Word64Word64Word64Word64Word64Word64Word64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64 !(USet (Word64,Word64,Word64,Word64,Word64,Word64,Word64)) !(USet (Word64,Word64,Word64,Word64,Word64,Word64,Word64))
    view Word64Word64Word64Word64Word64Word64Word64Tip = Tip
    view (Word64Word64Word64Word64Word64Word64Word64Bin s a b c d e f g l r) = Bin s (a,b,c,d,e,f,g) l r
    tip = Word64Word64Word64Word64Word64Word64Word64Tip
    bin s (a,b,c,d,e,f,g) = Word64Word64Word64Word64Word64Word64Word64Bin s a b c d e f g

instance US (Word64,Word64,Word64,Word64,Word64,Word64,Word64,Word64) where
    data USet (Word64,Word64,Word64,Word64,Word64,Word64,Word64,Word64) = Word64Word64Word64Word64Word64Word64Word64Word64Tip | Word64Word64Word64Word64Word64Word64Word64Word64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64 !(USet (Word64,Word64,Word64,Word64,Word64,Word64,Word64,Word64)) !(USet (Word64,Word64,Word64,Word64,Word64,Word64,Word64,Word64))
    view Word64Word64Word64Word64Word64Word64Word64Word64Tip = Tip
    view (Word64Word64Word64Word64Word64Word64Word64Word64Bin s a b c d e f g h l r) = Bin s (a,b,c,d,e,f,g,h) l r
    tip = Word64Word64Word64Word64Word64Word64Word64Word64Tip
    bin s (a,b,c,d,e,f,g,h) = Word64Word64Word64Word64Word64Word64Word64Word64Bin s a b c d e f g h

instance US (Word64,Word64,Word64,Word64,Word64,Word64,Word64,Word64,Word64) where
    data USet (Word64,Word64,Word64,Word64,Word64,Word64,Word64,Word64,Word64) = Word64Word64Word64Word64Word64Word64Word64Word64Word64Tip | Word64Word64Word64Word64Word64Word64Word64Word64Word64Bin {-# UNPACK #-} !Size {-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64{-# UNPACK #-} !Word64 !(USet (Word64,Word64,Word64,Word64,Word64,Word64,Word64,Word64,Word64)) !(USet (Word64,Word64,Word64,Word64,Word64,Word64,Word64,Word64,Word64))
    view Word64Word64Word64Word64Word64Word64Word64Word64Word64Tip = Tip
    view (Word64Word64Word64Word64Word64Word64Word64Word64Word64Bin s a b c d e f g h i l r) = Bin s (a,b,c,d,e,f,g,h,i) l r
    tip = Word64Word64Word64Word64Word64Word64Word64Word64Word64Tip
    bin s (a,b,c,d,e,f,g,h,i) = Word64Word64Word64Word64Word64Word64Word64Word64Word64Bin s a b c d e f g h i

instance US (Double,Double) where
    data USet (Double,Double) = DoubleDoubleTip | DoubleDoubleBin {-# UNPACK #-} !Size {-# UNPACK #-} !Double{-# UNPACK #-} !Double !(USet (Double,Double)) !(USet (Double,Double))
    view DoubleDoubleTip = Tip
    view (DoubleDoubleBin s a b l r) = Bin s (a,b) l r
    tip = DoubleDoubleTip
    bin s (a,b) = DoubleDoubleBin s a b

instance US (Double,Double,Double) where
    data USet (Double,Double,Double) = DoubleDoubleDoubleTip | DoubleDoubleDoubleBin {-# UNPACK #-} !Size {-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double !(USet (Double,Double,Double)) !(USet (Double,Double,Double))
    view DoubleDoubleDoubleTip = Tip
    view (DoubleDoubleDoubleBin s a b c l r) = Bin s (a,b,c) l r
    tip = DoubleDoubleDoubleTip
    bin s (a,b,c) = DoubleDoubleDoubleBin s a b c

instance US (Double,Double,Double,Double) where
    data USet (Double,Double,Double,Double) = DoubleDoubleDoubleDoubleTip | DoubleDoubleDoubleDoubleBin {-# UNPACK #-} !Size {-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double !(USet (Double,Double,Double,Double)) !(USet (Double,Double,Double,Double))
    view DoubleDoubleDoubleDoubleTip = Tip
    view (DoubleDoubleDoubleDoubleBin s a b c d l r) = Bin s (a,b,c,d) l r
    tip = DoubleDoubleDoubleDoubleTip
    bin s (a,b,c,d) = DoubleDoubleDoubleDoubleBin s a b c d

instance US (Double,Double,Double,Double,Double) where
    data USet (Double,Double,Double,Double,Double) = DoubleDoubleDoubleDoubleDoubleTip | DoubleDoubleDoubleDoubleDoubleBin {-# UNPACK #-} !Size {-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double !(USet (Double,Double,Double,Double,Double)) !(USet (Double,Double,Double,Double,Double))
    view DoubleDoubleDoubleDoubleDoubleTip = Tip
    view (DoubleDoubleDoubleDoubleDoubleBin s a b c d e l r) = Bin s (a,b,c,d,e) l r
    tip = DoubleDoubleDoubleDoubleDoubleTip
    bin s (a,b,c,d,e) = DoubleDoubleDoubleDoubleDoubleBin s a b c d e

instance US (Double,Double,Double,Double,Double,Double) where
    data USet (Double,Double,Double,Double,Double,Double) = DoubleDoubleDoubleDoubleDoubleDoubleTip | DoubleDoubleDoubleDoubleDoubleDoubleBin {-# UNPACK #-} !Size {-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double !(USet (Double,Double,Double,Double,Double,Double)) !(USet (Double,Double,Double,Double,Double,Double))
    view DoubleDoubleDoubleDoubleDoubleDoubleTip = Tip
    view (DoubleDoubleDoubleDoubleDoubleDoubleBin s a b c d e f l r) = Bin s (a,b,c,d,e,f) l r
    tip = DoubleDoubleDoubleDoubleDoubleDoubleTip
    bin s (a,b,c,d,e,f) = DoubleDoubleDoubleDoubleDoubleDoubleBin s a b c d e f

instance US (Double,Double,Double,Double,Double,Double,Double) where
    data USet (Double,Double,Double,Double,Double,Double,Double) = DoubleDoubleDoubleDoubleDoubleDoubleDoubleTip | DoubleDoubleDoubleDoubleDoubleDoubleDoubleBin {-# UNPACK #-} !Size {-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double !(USet (Double,Double,Double,Double,Double,Double,Double)) !(USet (Double,Double,Double,Double,Double,Double,Double))
    view DoubleDoubleDoubleDoubleDoubleDoubleDoubleTip = Tip
    view (DoubleDoubleDoubleDoubleDoubleDoubleDoubleBin s a b c d e f g l r) = Bin s (a,b,c,d,e,f,g) l r
    tip = DoubleDoubleDoubleDoubleDoubleDoubleDoubleTip
    bin s (a,b,c,d,e,f,g) = DoubleDoubleDoubleDoubleDoubleDoubleDoubleBin s a b c d e f g

instance US (Double,Double,Double,Double,Double,Double,Double,Double) where
    data USet (Double,Double,Double,Double,Double,Double,Double,Double) = DoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleTip | DoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleBin {-# UNPACK #-} !Size {-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double !(USet (Double,Double,Double,Double,Double,Double,Double,Double)) !(USet (Double,Double,Double,Double,Double,Double,Double,Double))
    view DoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleTip = Tip
    view (DoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleBin s a b c d e f g h l r) = Bin s (a,b,c,d,e,f,g,h) l r
    tip = DoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleTip
    bin s (a,b,c,d,e,f,g,h) = DoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleBin s a b c d e f g h

instance US (Double,Double,Double,Double,Double,Double,Double,Double,Double) where
    data USet (Double,Double,Double,Double,Double,Double,Double,Double,Double) = DoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleTip | DoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleBin {-# UNPACK #-} !Size {-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double{-# UNPACK #-} !Double !(USet (Double,Double,Double,Double,Double,Double,Double,Double,Double)) !(USet (Double,Double,Double,Double,Double,Double,Double,Double,Double))
    view DoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleTip = Tip
    view (DoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleBin s a b c d e f g h i l r) = Bin s (a,b,c,d,e,f,g,h,i) l r
    tip = DoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleTip
    bin s (a,b,c,d,e,f,g,h,i) = DoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleDoubleBin s a b c d e f g h i

instance US (Float,Float) where
    data USet (Float,Float) = FloatFloatTip | FloatFloatBin {-# UNPACK #-} !Size {-# UNPACK #-} !Float{-# UNPACK #-} !Float !(USet (Float,Float)) !(USet (Float,Float))
    view FloatFloatTip = Tip
    view (FloatFloatBin s a b l r) = Bin s (a,b) l r
    tip = FloatFloatTip
    bin s (a,b) = FloatFloatBin s a b

instance US (Float,Float,Float) where
    data USet (Float,Float,Float) = FloatFloatFloatTip | FloatFloatFloatBin {-# UNPACK #-} !Size {-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float !(USet (Float,Float,Float)) !(USet (Float,Float,Float))
    view FloatFloatFloatTip = Tip
    view (FloatFloatFloatBin s a b c l r) = Bin s (a,b,c) l r
    tip = FloatFloatFloatTip
    bin s (a,b,c) = FloatFloatFloatBin s a b c

instance US (Float,Float,Float,Float) where
    data USet (Float,Float,Float,Float) = FloatFloatFloatFloatTip | FloatFloatFloatFloatBin {-# UNPACK #-} !Size {-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float !(USet (Float,Float,Float,Float)) !(USet (Float,Float,Float,Float))
    view FloatFloatFloatFloatTip = Tip
    view (FloatFloatFloatFloatBin s a b c d l r) = Bin s (a,b,c,d) l r
    tip = FloatFloatFloatFloatTip
    bin s (a,b,c,d) = FloatFloatFloatFloatBin s a b c d

instance US (Float,Float,Float,Float,Float) where
    data USet (Float,Float,Float,Float,Float) = FloatFloatFloatFloatFloatTip | FloatFloatFloatFloatFloatBin {-# UNPACK #-} !Size {-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float !(USet (Float,Float,Float,Float,Float)) !(USet (Float,Float,Float,Float,Float))
    view FloatFloatFloatFloatFloatTip = Tip
    view (FloatFloatFloatFloatFloatBin s a b c d e l r) = Bin s (a,b,c,d,e) l r
    tip = FloatFloatFloatFloatFloatTip
    bin s (a,b,c,d,e) = FloatFloatFloatFloatFloatBin s a b c d e

instance US (Float,Float,Float,Float,Float,Float) where
    data USet (Float,Float,Float,Float,Float,Float) = FloatFloatFloatFloatFloatFloatTip | FloatFloatFloatFloatFloatFloatBin {-# UNPACK #-} !Size {-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float !(USet (Float,Float,Float,Float,Float,Float)) !(USet (Float,Float,Float,Float,Float,Float))
    view FloatFloatFloatFloatFloatFloatTip = Tip
    view (FloatFloatFloatFloatFloatFloatBin s a b c d e f l r) = Bin s (a,b,c,d,e,f) l r
    tip = FloatFloatFloatFloatFloatFloatTip
    bin s (a,b,c,d,e,f) = FloatFloatFloatFloatFloatFloatBin s a b c d e f

instance US (Float,Float,Float,Float,Float,Float,Float) where
    data USet (Float,Float,Float,Float,Float,Float,Float) = FloatFloatFloatFloatFloatFloatFloatTip | FloatFloatFloatFloatFloatFloatFloatBin {-# UNPACK #-} !Size {-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float !(USet (Float,Float,Float,Float,Float,Float,Float)) !(USet (Float,Float,Float,Float,Float,Float,Float))
    view FloatFloatFloatFloatFloatFloatFloatTip = Tip
    view (FloatFloatFloatFloatFloatFloatFloatBin s a b c d e f g l r) = Bin s (a,b,c,d,e,f,g) l r
    tip = FloatFloatFloatFloatFloatFloatFloatTip
    bin s (a,b,c,d,e,f,g) = FloatFloatFloatFloatFloatFloatFloatBin s a b c d e f g

instance US (Float,Float,Float,Float,Float,Float,Float,Float) where
    data USet (Float,Float,Float,Float,Float,Float,Float,Float) = FloatFloatFloatFloatFloatFloatFloatFloatTip | FloatFloatFloatFloatFloatFloatFloatFloatBin {-# UNPACK #-} !Size {-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float !(USet (Float,Float,Float,Float,Float,Float,Float,Float)) !(USet (Float,Float,Float,Float,Float,Float,Float,Float))
    view FloatFloatFloatFloatFloatFloatFloatFloatTip = Tip
    view (FloatFloatFloatFloatFloatFloatFloatFloatBin s a b c d e f g h l r) = Bin s (a,b,c,d,e,f,g,h) l r
    tip = FloatFloatFloatFloatFloatFloatFloatFloatTip
    bin s (a,b,c,d,e,f,g,h) = FloatFloatFloatFloatFloatFloatFloatFloatBin s a b c d e f g h

instance US (Float,Float,Float,Float,Float,Float,Float,Float,Float) where
    data USet (Float,Float,Float,Float,Float,Float,Float,Float,Float) = FloatFloatFloatFloatFloatFloatFloatFloatFloatTip | FloatFloatFloatFloatFloatFloatFloatFloatFloatBin {-# UNPACK #-} !Size {-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float{-# UNPACK #-} !Float !(USet (Float,Float,Float,Float,Float,Float,Float,Float,Float)) !(USet (Float,Float,Float,Float,Float,Float,Float,Float,Float))
    view FloatFloatFloatFloatFloatFloatFloatFloatFloatTip = Tip
    view (FloatFloatFloatFloatFloatFloatFloatFloatFloatBin s a b c d e f g h i l r) = Bin s (a,b,c,d,e,f,g,h,i) l r
    tip = FloatFloatFloatFloatFloatFloatFloatFloatFloatTip
    bin s (a,b,c,d,e,f,g,h,i) = FloatFloatFloatFloatFloatFloatFloatFloatFloatBin s a b c d e f g h i

instance US (Integer,Integer) where
    data USet (Integer,Integer) = IntegerIntegerTip | IntegerIntegerBin {-# UNPACK #-} !Size {-# UNPACK #-} !Integer{-# UNPACK #-} !Integer !(USet (Integer,Integer)) !(USet (Integer,Integer))
    view IntegerIntegerTip = Tip
    view (IntegerIntegerBin s a b l r) = Bin s (a,b) l r
    tip = IntegerIntegerTip
    bin s (a,b) = IntegerIntegerBin s a b

instance US (Integer,Integer,Integer) where
    data USet (Integer,Integer,Integer) = IntegerIntegerIntegerTip | IntegerIntegerIntegerBin {-# UNPACK #-} !Size {-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer !(USet (Integer,Integer,Integer)) !(USet (Integer,Integer,Integer))
    view IntegerIntegerIntegerTip = Tip
    view (IntegerIntegerIntegerBin s a b c l r) = Bin s (a,b,c) l r
    tip = IntegerIntegerIntegerTip
    bin s (a,b,c) = IntegerIntegerIntegerBin s a b c

instance US (Integer,Integer,Integer,Integer) where
    data USet (Integer,Integer,Integer,Integer) = IntegerIntegerIntegerIntegerTip | IntegerIntegerIntegerIntegerBin {-# UNPACK #-} !Size {-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer !(USet (Integer,Integer,Integer,Integer)) !(USet (Integer,Integer,Integer,Integer))
    view IntegerIntegerIntegerIntegerTip = Tip
    view (IntegerIntegerIntegerIntegerBin s a b c d l r) = Bin s (a,b,c,d) l r
    tip = IntegerIntegerIntegerIntegerTip
    bin s (a,b,c,d) = IntegerIntegerIntegerIntegerBin s a b c d

instance US (Integer,Integer,Integer,Integer,Integer) where
    data USet (Integer,Integer,Integer,Integer,Integer) = IntegerIntegerIntegerIntegerIntegerTip | IntegerIntegerIntegerIntegerIntegerBin {-# UNPACK #-} !Size {-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer !(USet (Integer,Integer,Integer,Integer,Integer)) !(USet (Integer,Integer,Integer,Integer,Integer))
    view IntegerIntegerIntegerIntegerIntegerTip = Tip
    view (IntegerIntegerIntegerIntegerIntegerBin s a b c d e l r) = Bin s (a,b,c,d,e) l r
    tip = IntegerIntegerIntegerIntegerIntegerTip
    bin s (a,b,c,d,e) = IntegerIntegerIntegerIntegerIntegerBin s a b c d e

instance US (Integer,Integer,Integer,Integer,Integer,Integer) where
    data USet (Integer,Integer,Integer,Integer,Integer,Integer) = IntegerIntegerIntegerIntegerIntegerIntegerTip | IntegerIntegerIntegerIntegerIntegerIntegerBin {-# UNPACK #-} !Size {-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer !(USet (Integer,Integer,Integer,Integer,Integer,Integer)) !(USet (Integer,Integer,Integer,Integer,Integer,Integer))
    view IntegerIntegerIntegerIntegerIntegerIntegerTip = Tip
    view (IntegerIntegerIntegerIntegerIntegerIntegerBin s a b c d e f l r) = Bin s (a,b,c,d,e,f) l r
    tip = IntegerIntegerIntegerIntegerIntegerIntegerTip
    bin s (a,b,c,d,e,f) = IntegerIntegerIntegerIntegerIntegerIntegerBin s a b c d e f

instance US (Integer,Integer,Integer,Integer,Integer,Integer,Integer) where
    data USet (Integer,Integer,Integer,Integer,Integer,Integer,Integer) = IntegerIntegerIntegerIntegerIntegerIntegerIntegerTip | IntegerIntegerIntegerIntegerIntegerIntegerIntegerBin {-# UNPACK #-} !Size {-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer !(USet (Integer,Integer,Integer,Integer,Integer,Integer,Integer)) !(USet (Integer,Integer,Integer,Integer,Integer,Integer,Integer))
    view IntegerIntegerIntegerIntegerIntegerIntegerIntegerTip = Tip
    view (IntegerIntegerIntegerIntegerIntegerIntegerIntegerBin s a b c d e f g l r) = Bin s (a,b,c,d,e,f,g) l r
    tip = IntegerIntegerIntegerIntegerIntegerIntegerIntegerTip
    bin s (a,b,c,d,e,f,g) = IntegerIntegerIntegerIntegerIntegerIntegerIntegerBin s a b c d e f g

instance US (Integer,Integer,Integer,Integer,Integer,Integer,Integer,Integer) where
    data USet (Integer,Integer,Integer,Integer,Integer,Integer,Integer,Integer) = IntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerTip | IntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerBin {-# UNPACK #-} !Size {-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer !(USet (Integer,Integer,Integer,Integer,Integer,Integer,Integer,Integer)) !(USet (Integer,Integer,Integer,Integer,Integer,Integer,Integer,Integer))
    view IntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerTip = Tip
    view (IntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerBin s a b c d e f g h l r) = Bin s (a,b,c,d,e,f,g,h) l r
    tip = IntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerTip
    bin s (a,b,c,d,e,f,g,h) = IntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerBin s a b c d e f g h

instance US (Integer,Integer,Integer,Integer,Integer,Integer,Integer,Integer,Integer) where
    data USet (Integer,Integer,Integer,Integer,Integer,Integer,Integer,Integer,Integer) = IntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerTip | IntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerBin {-# UNPACK #-} !Size {-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer{-# UNPACK #-} !Integer !(USet (Integer,Integer,Integer,Integer,Integer,Integer,Integer,Integer,Integer)) !(USet (Integer,Integer,Integer,Integer,Integer,Integer,Integer,Integer,Integer))
    view IntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerTip = Tip
    view (IntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerBin s a b c d e f g h i l r) = Bin s (a,b,c,d,e,f,g,h,i) l r
    tip = IntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerTip
    bin s (a,b,c,d,e,f,g,h,i) = IntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerIntegerBin s a b c d e f g h i

instance US (Boxed a,Boxed b) where
    data USet (Boxed a,Boxed b) = BoxedBoxedTip | BoxedBoxedBin {-# UNPACK #-} !Size (Boxed a)(Boxed b) !(USet (Boxed a,Boxed b)) !(USet (Boxed a,Boxed b))
    view BoxedBoxedTip = Tip
    view (BoxedBoxedBin s a b l r) = Bin s (a,b) l r
    tip = BoxedBoxedTip
    bin s (a,b) = BoxedBoxedBin s a b

instance US (Boxed a,Boxed b,Boxed c) where
    data USet (Boxed a,Boxed b,Boxed c) = BoxedBoxedBoxedTip | BoxedBoxedBoxedBin {-# UNPACK #-} !Size (Boxed a)(Boxed b)(Boxed c) !(USet (Boxed a,Boxed b,Boxed c)) !(USet (Boxed a,Boxed b,Boxed c))
    view BoxedBoxedBoxedTip = Tip
    view (BoxedBoxedBoxedBin s a b c l r) = Bin s (a,b,c) l r
    tip = BoxedBoxedBoxedTip
    bin s (a,b,c) = BoxedBoxedBoxedBin s a b c

instance US (Boxed a,Boxed b,Boxed c,Boxed d) where
    data USet (Boxed a,Boxed b,Boxed c,Boxed d) = BoxedBoxedBoxedBoxedTip | BoxedBoxedBoxedBoxedBin {-# UNPACK #-} !Size (Boxed a)(Boxed b)(Boxed c)(Boxed d) !(USet (Boxed a,Boxed b,Boxed c,Boxed d)) !(USet (Boxed a,Boxed b,Boxed c,Boxed d))
    view BoxedBoxedBoxedBoxedTip = Tip
    view (BoxedBoxedBoxedBoxedBin s a b c d l r) = Bin s (a,b,c,d) l r
    tip = BoxedBoxedBoxedBoxedTip
    bin s (a,b,c,d) = BoxedBoxedBoxedBoxedBin s a b c d

instance US (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e) where
    data USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e) = BoxedBoxedBoxedBoxedBoxedTip | BoxedBoxedBoxedBoxedBoxedBin {-# UNPACK #-} !Size (Boxed a)(Boxed b)(Boxed c)(Boxed d)(Boxed e) !(USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e)) !(USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e))
    view BoxedBoxedBoxedBoxedBoxedTip = Tip
    view (BoxedBoxedBoxedBoxedBoxedBin s a b c d e l r) = Bin s (a,b,c,d,e) l r
    tip = BoxedBoxedBoxedBoxedBoxedTip
    bin s (a,b,c,d,e) = BoxedBoxedBoxedBoxedBoxedBin s a b c d e

instance US (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f) where
    data USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f) = BoxedBoxedBoxedBoxedBoxedBoxedTip | BoxedBoxedBoxedBoxedBoxedBoxedBin {-# UNPACK #-} !Size (Boxed a)(Boxed b)(Boxed c)(Boxed d)(Boxed e)(Boxed f) !(USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f)) !(USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f))
    view BoxedBoxedBoxedBoxedBoxedBoxedTip = Tip
    view (BoxedBoxedBoxedBoxedBoxedBoxedBin s a b c d e f l r) = Bin s (a,b,c,d,e,f) l r
    tip = BoxedBoxedBoxedBoxedBoxedBoxedTip
    bin s (a,b,c,d,e,f) = BoxedBoxedBoxedBoxedBoxedBoxedBin s a b c d e f

instance US (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f,Boxed g) where
    data USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f,Boxed g) = BoxedBoxedBoxedBoxedBoxedBoxedBoxedTip | BoxedBoxedBoxedBoxedBoxedBoxedBoxedBin {-# UNPACK #-} !Size (Boxed a)(Boxed b)(Boxed c)(Boxed d)(Boxed e)(Boxed f)(Boxed g) !(USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f,Boxed g)) !(USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f,Boxed g))
    view BoxedBoxedBoxedBoxedBoxedBoxedBoxedTip = Tip
    view (BoxedBoxedBoxedBoxedBoxedBoxedBoxedBin s a b c d e f g l r) = Bin s (a,b,c,d,e,f,g) l r
    tip = BoxedBoxedBoxedBoxedBoxedBoxedBoxedTip
    bin s (a,b,c,d,e,f,g) = BoxedBoxedBoxedBoxedBoxedBoxedBoxedBin s a b c d e f g

instance US (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f,Boxed g,Boxed h) where
    data USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f,Boxed g,Boxed h) = BoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedTip | BoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedBin {-# UNPACK #-} !Size (Boxed a)(Boxed b)(Boxed c)(Boxed d)(Boxed e)(Boxed f)(Boxed g)(Boxed h) !(USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f,Boxed g,Boxed h)) !(USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f,Boxed g,Boxed h))
    view BoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedTip = Tip
    view (BoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedBin s a b c d e f g h l r) = Bin s (a,b,c,d,e,f,g,h) l r
    tip = BoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedTip
    bin s (a,b,c,d,e,f,g,h) = BoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedBin s a b c d e f g h

instance US (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f,Boxed g,Boxed h,Boxed i) where
    data USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f,Boxed g,Boxed h,Boxed i) = BoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedTip | BoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedBin {-# UNPACK #-} !Size (Boxed a)(Boxed b)(Boxed c)(Boxed d)(Boxed e)(Boxed f)(Boxed g)(Boxed h)(Boxed i) !(USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f,Boxed g,Boxed h,Boxed i)) !(USet (Boxed a,Boxed b,Boxed c,Boxed d,Boxed e,Boxed f,Boxed g,Boxed h,Boxed i))
    view BoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedTip = Tip
    view (BoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedBin s a b c d e f g h i l r) = Bin s (a,b,c,d,e,f,g,h,i) l r
    tip = BoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedTip
    bin s (a,b,c,d,e,f,g,h,i) = BoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedBoxedBin s a b c d e f g h i

