-----------------------------------------------------------------------------
-- |
-- Module      :  Data.Monoid.Additive.Sugar
-- Copyright   :  (c) Edward Kmett 2009
-- License     :  BSD-style
-- Maintainer  :  libraries@haskell.org
-- Stability   :  experimental
-- Portability :  portable
--
-- Syntactic sugar for working with a 'Monoid' that conflicts with names from the "Prelude".
--
-- > import Prelude hiding ((+))
-- > import Data.Monoid.Additive.Sugar
--
-----------------------------------------------------------------------------

module Data.Monoid.Additive.Sugar 
    ( module Data.Monoid.Additive
    , (+)
    ) where

import Data.Monoid.Additive
import Prelude hiding ((+))

infixl 6 + 

(+) :: Monoid m => m -> m -> m 
(+) = mappend
