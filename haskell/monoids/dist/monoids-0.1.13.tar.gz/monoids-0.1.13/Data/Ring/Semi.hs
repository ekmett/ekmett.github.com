-----------------------------------------------------------------------------
-- |
-- Module      :  Data.Ring.Semi
-- Copyright   :  (c) Edward Kmett 2009
-- License     :  BSD-style
-- Maintainer  :  libraries@haskell.org
-- Stability   :  experimental
-- Portability :  non-portable (MPTCs)
--
--
-----------------------------------------------------------------------------

module Data.Ring.Semi
    ( module Data.Ring.Semi.Near
    , SemiRing
    ) where

import Data.Ring.Semi.Near

-- | A 'SemiRing' is an instance of both 'Multiplicative' and 'Monoid' where 
--   'times' distributes over 'plus'.
class (RightSemiNearRing a, LeftSemiNearRing a) => SemiRing a
