-----------------------------------------------------------------------------
-- |
-- Module      :  Data.Monoid.Multiplicative.Sugar
-- Copyright   :  (c) Edward Kmett 2009
-- License     :  BSD-style
-- Maintainer  :  libraries@haskell.org
-- Stability   :  experimental
-- Portability :  portable
--
-- Syntactic sugar for working with a 'Multiplicative' monoids that conflicts with names from the "Prelude".
--
-- > import Prelude hiding ((+),(*))
-- > import Data.Monoid.Multiplicative.Sugar
--
-----------------------------------------------------------------------------

module Data.Monoid.Multiplicative.Sugar
    ( module Data.Monoid.Additive.Sugar
    , module Data.Monoid.Multiplicative
    , (*)
    ) where

import Data.Monoid.Additive.Sugar
import Data.Monoid.Multiplicative
import Prelude hiding ((*))

infixl 7 *

(*) :: Multiplicative r => r -> r -> r
(*) = times
