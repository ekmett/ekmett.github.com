-----------------------------------------------------------------------------
-- |
-- Module      :  Data.Field
-- Copyright   :  (c) Edward Kmett 2009
-- License     :  BSD-style
-- Maintainer  :  ekmett@gmail.com
-- Stability   :  experimental
-- Portability :  portable
--
-----------------------------------------------------------------------------

module Data.Field
    ( module Data.Group.Multiplicative
    , module Data.Ring
    , Field
    ) where

import Data.Group.Multiplicative
import Data.Ring
import Data.Monoid.Self
import Data.Monoid.FromString
import Data.Monoid.Reducer

class (Ring a, MultiplicativeGroup a) => Field a

instance Field f => Field (Dual f)
instance Field f => Field (Self f)
instance Field f => Field (FromString f)
instance Field f => Field (ReducedBy f s)
