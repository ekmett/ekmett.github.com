module Data.Ring.Semi.Kleene 
    ( module Data.Ring.Semi
    , KleeneAlgebra
    , star
    ) where

import Data.Ring.Semi

class SemiRing r => KleeneAlgebra r where
    star :: r -> r
