{-# OPTIONS_GHC -fno-warn-orphans #-}
{-# LANGUAGE FlexibleInstances, MultiParamTypeClasses, UndecidableInstances #-}

-----------------------------------------------------------------------------
-- |
-- Module      :  Data.Ring
-- Copyright   :  (c) Edward Kmett 2009
-- License     :  BSD-style
-- Maintainer  :  ekmett@gmail.com
-- Stability   :  experimental
-- Portability :  portable (instances use MPTCs)
--
-----------------------------------------------------------------------------

module Data.Ring
    ( module Data.Group
    , module Data.Ring.Semi
    , Ring
    ) where

import Data.Group
import Data.Ring.Semi

class (Group a, SemiRing a) => Ring a
