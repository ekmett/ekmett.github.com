{-# LANGUAGE MultiParamTypeClasses, FlexibleInstances, FlexibleContexts #-}
module Data.Ring.Algebra
    ( module Data.Ring.Module
    , RAlgebra
    ) where

import Data.Ring.Module

-- | Algebra over a (near) (semi) ring.
--
-- @r *. (x * y) = (r *. x) * y = x * (r *. y)@
--
-- @(x * y) .* r = y * (x .* r) = (y .* r) * x@
class (r `Module` m, Multiplicative m) => RAlgebra r m 
