{-# OPTIONS_GHC -fno-warn-orphans #-}
module Data.Ring
    ( module Data.Group
    , module Data.Ring.Semi
    , Ring
    ) where

import Data.Group
import Data.Ring.Semi

class (Group a, SemiRing a) => Ring a
