-----------------------------------------------------------------------------
-- |
-- Module      :  Data.Ring.Sugar
-- Copyright   :  (c) Edward Kmett 2009
-- License     :  BSD-style
-- Maintainer  :  libraries@haskell.org
-- Stability   :  experimental
-- Portability :  portable
--
-- Syntactic sugar for working with rings that conflicts with names from the "Prelude".
--
-- > import Prelude hiding ((-), (+), (*), negate, subtract)
-- > import Data.Ring.Sugar
--
-----------------------------------------------------------------------------

module Data.Ring.Sugar 
    ( module Data.Monoid.Multiplicative.Sugar
    , module Data.Ring.Semi.Near
    ) where

import Data.Monoid.Multiplicative.Sugar
import Data.Ring.Semi.Near
