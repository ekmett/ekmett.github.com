-----------------------------------------------------------------------------
-- |
-- Module      :  Data.Group.Sugar
-- Copyright   :  (c) Edward Kmett 2009
-- License     :  BSD-style
-- Maintainer  :  libraries@haskell.org
-- Stability   :  experimental
-- Portability :  portable
--
-- Syntactic sugar for working with groups that conflicts with names from the "Prelude".
--
-- > import Prelude hiding ((-), (+), negate, subtract)
-- > import Data.Group.Sugar
--
-----------------------------------------------------------------------------

module Data.Group.Sugar 
    ( module Data.Monoid.Additive.Sugar
    , module Data.Group
    , (-)
    , negate
    , subtract
    ) where

import Data.Monoid.Additive.Sugar
import Data.Group
import Prelude hiding ((-), negate, subtract)

infixl 7 -

(-) :: Group g => g -> g -> g
(-) = minus

negate :: Group g => g -> g
negate = gnegate

subtract :: Group g => g -> g -> g
subtract = gsubtract
