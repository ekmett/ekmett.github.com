----------------------------------------------------------------------------
-- |
-- Module     : Data.Group
-- Copyright  : 2007-2009 Edward Kmett
-- License    : BSD
--
-- Maintainer  : Edward Kmett <ekmett@gmail.com>
-- Stability   : experimental
-- Portability : portable
--
-- Extends 'Monoid' to support 'Group' operations
-----------------------------------------------------------------------------

module Data.Group 
    ( module Data.Monoid.Additive
    , Group
    , gnegate
    , gsubtract
    , minus
    ) where

import Data.Monoid.Additive
import Data.Monoid.Self
import Data.Monoid.FromString
import Data.Monoid.Reducer

infixl 6 `minus`

-- | Minimal complete definition: 'gnegate' or 'minus'
class Monoid a => Group a where
    -- additive inverse
    gnegate :: a -> a
    minus :: a -> a -> a
    gsubtract :: a -> a -> a 

    gnegate = minus zero
    a `minus` b = a `plus` gnegate b 
    a `gsubtract` b = gnegate a `plus` b

instance Num a => Group (Sum a) where
    gnegate = Sum . negate . getSum
    Sum a `minus` Sum b = Sum (a - b)
    
instance Fractional a => Group (Product a) where
    gnegate = Product . negate . getProduct
    Product a `minus` Product b = Product (a / b)
    
instance Group a => Group (Dual a) where
    gnegate = Dual . gnegate . getDual

instance Group a => Group (Self a) where
    gnegate = Self . gnegate . getSelf
    Self a `minus` Self b = Self (a `minus` b)

instance Group a => Group (FromString a) where
    gnegate = FromString . gnegate . getFromString
    FromString a `minus` FromString b = FromString (a `minus` b)

instance Group a => Group (ReducedBy a s) where
    gnegate = Reduction . gnegate . getReduction
    Reduction a `minus` Reduction b = Reduction (a `minus` b)

