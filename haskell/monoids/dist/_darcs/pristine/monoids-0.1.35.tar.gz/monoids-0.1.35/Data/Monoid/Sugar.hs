-----------------------------------------------------------------------------
-- |
-- Module      :  Data.Monoid.Additive.Sugar
-- Copyright   :  (c) Edward Kmett 2009
-- License     :  BSD-style
-- Maintainer  :  ekmett@gmail.com
-- Stability   :  experimental
-- Portability :  portable
--
-- Syntactic sugar for working with a 'Monoid' and 'Multiplicative' instances 
-- that conflicts with names from the "Prelude".
--
-- > import Prelude hiding ((+),(*),(^))
-- > import Data.Monoid.Sugar
--
-----------------------------------------------------------------------------
--
module Data.Monoid.Sugar
    ( module Data.Monoid.Multiplicative
    , module Data.Ring.Semi.Natural
    , (+)
    , (*)
    , (^)
    ) where

import Prelude hiding ((*),(^),(+))
import Data.Monoid.Multiplicative
import Data.Ring.Semi.Natural
import qualified Data.Monoid.Combinators as Monoid

infixl 6 + 
infixl 7 *

(+) :: Monoid m => m -> m -> m 
(+) = mappend

(*) :: Multiplicative r => r -> r -> r
(*) = times

(^) :: Multiplicative r => r -> Natural -> r
r ^ n = getLog (Monoid.replicate (Log r) n)
