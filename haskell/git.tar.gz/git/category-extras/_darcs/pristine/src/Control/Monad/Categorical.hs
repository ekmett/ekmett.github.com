module Control.Monad.Categorical 
	(CMonad, CBind(..), CPointed(..)) where

import Prelude hiding (id,(.))
import Control.Functor.Categorical
