-------------------------------------------------------------------------------------------
-- |
-- Module	: Control.Category.Comonad.Reader
-- Copyright 	: 2008 Edward Kmett
-- License	: BSD-style (see the LICENSE file in the distribution)
--
-- Maintainer	: Edward Kmett <ekmett@gmail.com>
-- Stability	: experimental
-- Portability	: non-portable (class-associated types)
--
-------------------------------------------------------------------------------------------

module Control.Category.Comonad.Reader where

import Prelude hiding (Functor, fmap, (.), id, fst, snd)
import Control.Category
import Control.Category.Functor
import Control.Category.Morphism
import Control.Category.Cartesian.Product
import Control.Category.Comonad
import Control.Category.Bifunctor
import Control.Category.Bifunctor.Associative
import Control.Category.Functor.Pointed

newtype ReaderW e k a = ReaderW (Prod k a e)

--instance (Canonical k (ReaderW e k a) (Prod k a e), HasProducts k) => Functor (ReaderW e k) k k where
--	map = mapComonad 
--
--instance (Canonical k (ReaderW e k a) (Prod k a e), HasProducts k) => Copointed (ReaderW e k) k where
--	extract = fst . iso
--
--instance (Canonical k (ReaderW e k a) (Prod k a e), HasProducts k) => Comonad (ReaderW e k) k where
--	extend k = uniso . (k &&& snd) . iso
--	duplicate = uniso .  coassociate . second diag . iso
