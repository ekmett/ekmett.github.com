#ifndef DEFINED_JS
#define DEFINED_JS
var js={};
#endif
