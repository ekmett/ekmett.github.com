#ifndef DEFINED_JS
#define DEFINED_JS
#define DEFINED_JS_LANG
var js={lang:{}};
#endif
#ifndef DEFINED_JS_LANG
#define DEFINED_JS_LANG
js.lang={};
#endif
