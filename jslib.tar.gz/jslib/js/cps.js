#ifndef DEFINED_JS
#define DEFINED_JS
#define DEFINED_JS_CPS
var js={cps:{}};
#endif
#ifndef DEFINED_JS_CPS
#define DEFINED_JS_CPS
js.cps={};
#endif
