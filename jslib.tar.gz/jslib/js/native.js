#ifndef DEFINED_JS
#define DEFINED_JS
#define DEFINED_JS_NATIVE
var js={native:{}};
#endif
#ifndef DEFINED_JS_NATIVE
#define DEFINED_JS_NATIVE
js.native={};
#endif
