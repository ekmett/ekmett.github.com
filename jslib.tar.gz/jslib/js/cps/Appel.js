// Appel.js Copyright 2006 Edward Kmett. All Rights Reserved.
#ifndef INCLUDED_JS_CPS_APPEL
#define INCLUDED_JS_CPS_APPEL

#include "js/cps/Appel.h"

#endif
