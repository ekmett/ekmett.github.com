#ifndef DEFINED_JS
#define DEFINED_JS
#define DEFINED_JS_AOP
var js={aop:{}};
#endif

#ifndef DEFINED_JS_AOP
#define DEFINED_JS_AOP
js.aop={};
#endif
