#ifndef DEFINED_JS
#define DEFINED_JS
#define DEFINED_JS_TEST
var js={test:{}};
#endif
#ifndef DEFINED_JS_TEST
#define DEFINED_JS_TEST
js.test={};
#endif
