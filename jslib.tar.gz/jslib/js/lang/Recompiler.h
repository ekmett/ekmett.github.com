#ifndef INCLUDED_JS_RECOMPILER_H
#define INCLUDED_JS_RECOMPILER_H

#define MARKED_MODE 	"marked"
#define NATIVE_MODE 	"native"
#define CONSTANT_MODE 	"constant"
#define CPS_MODE 	"cps"
#define DEFAULT_MODE	"marked"

#endif
