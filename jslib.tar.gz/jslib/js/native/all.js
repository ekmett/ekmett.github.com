#include "js/native/Platform.js"

#include "js/native/Array.js"
#include "js/native/Boolean.js"
#include "js/native/Function.js"
#include "js/native/Object.js"
#include "js/native/String.js"
#include "js/native/XMLHttpRequest.js"

#include "js/native/print.js"
