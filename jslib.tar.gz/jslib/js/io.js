#ifndef DEFINED_JS
#define DEFINED_JS
#define DEFINED_JS_IO
var js={io:{}};
#endif
#ifndef DEFINED_JS_IO
#define DEFINED_JS_IO
js.io={};
#endif
#include "js/io/common.js"
