#ifndef DEFINED_JS
#define DEFINED_JS
#define DEFINED_JS_MATH
var js={math:{}};
#endif
#ifndef DEFINED_JS_MATH
#define DEFINED_JS_MATH
js.math={};
#endif
