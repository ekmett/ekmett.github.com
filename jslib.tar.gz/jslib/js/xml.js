#ifndef DEFINED_JS
#define DEFINED_JS
#define DEFINED_JS_XML
var js={xml:{}};
#endif
#ifndef DEFINED_JS_XML
#define DEFINED_JS_XML
js.xml={};
#endif
