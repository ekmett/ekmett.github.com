#ifndef DEFINED_JS
#define DEFINED_JS
#define DEFINED_JS_NET
var js={net:{}};
#endif
#ifndef DEFINED_JS_NET
#define DEFINED_JS_NET
js.net={};
#endif
