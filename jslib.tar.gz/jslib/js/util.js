#ifndef DEFINED_JS
#define DEFINED_JS
#define DEFINED_JS_UTIL
var js={util:{}};
#endif
#ifndef DEFINED_JS_UTIL
#define DEFINED_JS_UTIL
js.util={};
#endif
