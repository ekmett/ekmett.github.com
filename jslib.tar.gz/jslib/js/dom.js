#ifndef DEFINED_JS
#define DEFINED_JS
#define DEFINED_JS_DOM
var js={dom:{}};
#endif
#ifndef DEFINED_JS_DOM
#define DEFINED_JS_DOM
js.dom={};
#endif
