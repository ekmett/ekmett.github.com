#include "js/aop/Aspect.js" // redirection stub
