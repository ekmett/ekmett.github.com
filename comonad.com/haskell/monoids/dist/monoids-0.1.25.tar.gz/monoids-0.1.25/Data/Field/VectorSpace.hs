{-# LANGUAGE MultiParamTypeClasses, FlexibleInstances, FlexibleContexts #-}
module Data.Field.VectorSpace 
    ( module Data.Field
    , module Data.Ring.Module
    , VectorSpace
    ) where

import Data.Field
import Data.Ring.Module
    
class (Field f, Module f g) => VectorSpace f g
