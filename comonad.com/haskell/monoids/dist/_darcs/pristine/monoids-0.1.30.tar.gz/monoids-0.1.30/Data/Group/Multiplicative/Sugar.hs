-----------------------------------------------------------------------------
-- |
-- Module      :  Data.Group.Multiplicative.Sugar
-- Copyright   :  (c) Edward Kmett 2009
-- License     :  BSD-style
-- Maintainer  :  ekmett@gmail.com
-- Stability   :  experimental
-- Portability :  portable
--
-- Syntactic sugar for working with groups that conflicts with names from the "Prelude".
--
-- > import Prelude hiding ((-), (+), (*), (/), negate, subtract, recip)
-- > import Data.Group.Multiplicative.Sugar
--
-----------------------------------------------------------------------------

module Data.Group.Multiplicative.Sugar 
    ( module Data.Monoid.Multiplicative.Sugar
    , module Data.Group.Multiplicative
    , module Data.Group.Sugar
    , (/)
    , (\\)
    , recip
    ) where

import Data.Group.Multiplicative
import Data.Monoid.Multiplicative.Sugar
import Data.Group.Sugar
import Prelude hiding ((-), (+), (*), (/), negate, subtract, recip)

infixl 7 /
infixr 7 \\

(/) :: MultiplicativeGroup g => g -> g -> g
(/) = over

(\\) :: MultiplicativeGroup g => g -> g -> g
(\\) = under

recip :: MultiplicativeGroup g => g -> g
recip = grecip
