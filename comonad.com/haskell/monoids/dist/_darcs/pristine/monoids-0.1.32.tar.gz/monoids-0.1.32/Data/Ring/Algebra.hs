{-# LANGUAGE MultiParamTypeClasses, FlexibleInstances, FlexibleContexts #-}
module Data.Ring.Algebra
    ( module Data.Ring.Module
    , Algebra
    ) where

import Data.Ring.Module

-- |  
-- @r *. (x * y) = (r *. x) * y = x * (r *. y)@
--
-- @(x * y) .* r = y * (x .* r) = (y .* r) * x@
class (r `Module` m, Multiplicative m) => Algebra r m 
