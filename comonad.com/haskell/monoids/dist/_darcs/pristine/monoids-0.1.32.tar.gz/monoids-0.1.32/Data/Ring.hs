-----------------------------------------------------------------------------
-- |
-- Module      :  Data.Ring
-- Copyright   :  (c) Edward Kmett 2009
-- License     :  BSD-style
-- Maintainer  :  ekmett@gmail.com
-- Stability   :  experimental
-- Portability :  portable (instances use MPTCs)
--
-----------------------------------------------------------------------------

module Data.Ring
    ( module Data.Group
    , module Data.Ring.Semi
    , Ring
    ) where

import Data.Group
import Data.Ring.Semi
import Data.Monoid.Self
import Data.Monoid.FromString

class (Group a, SemiRing a) => Ring a

instance Ring r => Ring (Self r)
instance Ring r => Ring (FromString r)
instance Ring r => Ring (ReducedBy r s)
instance Ring r => Ring (Dual r)
