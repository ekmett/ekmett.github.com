module Data.Logic.Ersatz.Bit
    ( Boolean(..)
    , Equatable(..)
    , Bit
    , bit
--  , assertBit
    ) where

import Data.Logic.Ersatz.Internal.Bit

-- assertBit :: MonadSAT b q => Bit b -> m ()
