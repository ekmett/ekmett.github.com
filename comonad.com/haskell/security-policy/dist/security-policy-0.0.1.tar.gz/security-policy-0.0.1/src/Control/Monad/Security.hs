{-# OPTIONS_GHC -fallow-undecidable-instances #-}

module Control.Monad.Security 
	( Policy
	, PolicyLevel
	, PolicyLattice
	, Access
	, witness
	, reclassify
	) where

import Control.Monad

-- | A `Policy` is a particular relationship between a closed set of `PolicyLevel`s. 
-- The closure of this set is maintained by limiting the export of the policy. 
class Policy p 

-- | A `PolicyLevel` is a particular point inside our capability space. You should not export the
-- data constructors for your PolicyLevels, but only export whatever methods you want to allow the
-- end user to deconstruct your secured data with including all access controls and permission checks.
class (Policy p, Monad l) => PolicyLevel p l | l -> p

class Monad l => Level l 
instance PolicyLevel p l => Level l


-- | Note instances of this class must form a full meet-semilattice for security purposes. 
class 
  ( Level l
  , Level l'
  , Level l''
  ) => PolicyLattice l l' l'' | l l' -> l'' 
  where
    -- | Parameterized bind. 
    witness :: l a -> (a -> l' b) -> l'' b

-- | @x & y = y iff x <= y@, semilattice law 
class PolicyLattice l m m => Access l m 
instance PolicyLattice l m m => Access l m

-- | raise the security level of a value using the supplied `witness` for the `PolicyLattice` relationship
reclassify :: Access l m => l a -> m a
reclassify x = (witness :: PolicyLattice l m m => l a -> (a -> m a) -> m a) x return
