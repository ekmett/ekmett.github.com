<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>404 Not Found</title>
</head><body>
<h1>Not Found</h1>
<p>The requested URL /haskell/category-extras/src/Control/Bifunctor/Fix.hs was not found on this server.</p>
<hr>
<address>Apache/2.2.22 (Ubuntu) DAV/2 PHP/5.4.9-4ubuntu2.1 Server at comonad.com Port 80</address>
</body></html>
